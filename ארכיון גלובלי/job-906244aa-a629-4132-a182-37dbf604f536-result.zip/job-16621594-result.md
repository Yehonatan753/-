## Input: https://www.perfectreef.co.il/248692-%D7%90%D7%99%D7%A0%D7%93%D7%A7%D7%A1-%D7%93%D7%92%D7%99-%D7%A0%D7%95%D7%99-

```md
שִׂים לֵב: בְּאֲתָר זֶה מֻפְעֶלֶת מַעֲרֶכֶת נָגִישׁ בִּקְלִיק הַמְּסַיַּעַת לִנְגִישׁוּת הָאֲתָר. לְחַץ Control-F11 לְהַתְאָמַת הָאֲתָר לְעִוְורִים הַמִּשְׁתַּמְּשִׁים בְּתוֹכְנַת קוֹרֵא־מָסָךְ; לְחַץ Control-F10 לִפְתִיחַת תַּפְרִיט נְגִישׁוּת.

Popup heading

Close

נגישות

* לְחַץ אֶנְטֵר לְהַתְאָמַת הָאֲתָר לְעִוְורִים הַמִּשְׁתַּמְּשִׁים בְּתוֹכְנַת קוֹרֵא־מָסָךְ.
* לְחַץ אֶנְטֵר לְנִוּוּט מִקְלֶדֶת
* לְחַץ אֶנְטֵר לִפְּתִיחַת תַּפְרִיט נְגִישׁוּת.

[משלוחים חינם לכל רחבי הארץ בקניה מעל 250 ש״ח \*לא כולל דגים ואקווריומים\* ](https://www.perfectreef.co.il/pages/47569-delivery) 

[ ![Perfect Reef](https://d3m9l0v76dty0.cloudfront.net/system/logos/6004/original/a5ee7eb5662c918953bd1c19d8e8e2d8.png) ](https://www.perfectreef.co.il/
 "Perfect Reef") 

* [](https://www.perfectreef.co.il/  
)
* [ עגלת הקניות 0 ](https://www.perfectreef.co.il/orders/perfectreef/new)

תוצאות: **4450** 

_[מחיר](/?order=up%5Fprice) | [שם](/?order=up%5Ftitle) מיין לפי:_ 

### 

פתח תפריט ניווט ![](https://d3m9l0v76dty0.cloudfront.net/system/photos/666133/original/7b3f18ccad90f5b6ab10be8360151224.svg?1644414833)

* [כל המוצרים](/?items=all)
* [אודות](https://www.perfectreef.co.il/about)
* [צור קשר](https://www.perfectreef.co.il/contact)
* [הגעה](https://www.perfectreef.co.il/location)
* [מאמרים](/245199-מאמרים)
* [דגי נוי](/248692)
* [דגי מים מלוחים](/248914)
* [התחברות](https://www.perfectreef.co.il/customer%5Flogin)
* [הרשמה](https://www.perfectreef.co.il/customer%5Fsignup)
* [מדיניות משלוחים](https://www.perfectreef.co.il/pages/47569-delivery)
* [הצהרת נגישות](https://www.perfectreef.co.il/pages/49966-%D7%94%D7%A6%D7%94%D7%A8%D7%AA-%D7%A0%D7%92%D7%99%D7%A9%D7%95%D7%AA)

### 

קטגוריות ראשיות

* [דגים](https://www.perfectreef.co.il/246269-%D7%93%D7%92%D7%99%D7%9D)  
   * [ אקווריומים ](https://www.perfectreef.co.il/246272-%D7%90%D7%A7%D7%95%D7%95%D7%A8%D7%99%D7%95%D7%9E%D7%99%D7%9D-)  
   * [ משאבות מים](https://www.perfectreef.co.il/248063-%D7%9E%D7%A9%D7%90%D7%91%D7%95%D7%AA-%D7%9E%D7%99%D7%9D)  
   * [ משאבות אוויר וציודן](https://www.perfectreef.co.il/248064-%D7%9E%D7%A9%D7%90%D7%91%D7%95%D7%AA-%D7%90%D7%95%D7%95%D7%99%D7%A8-%D7%95%D7%A6%D7%99%D7%95%D7%93%D7%9F)  
   * [ משאבות גלים](https://www.perfectreef.co.il/248067-%D7%9E%D7%A9%D7%90%D7%91%D7%95%D7%AA-%D7%92%D7%9C%D7%99%D7%9D)  
   * [ מדיות וסופחים ](https://www.perfectreef.co.il/246317-%D7%9E%D7%93%D7%99%D7%95%D7%AA-%D7%95%D7%A1%D7%95%D7%A4%D7%97%D7%99%D7%9D-)  
   * [ תכשירים ותוספים לאקווריום](https://www.perfectreef.co.il/247103-%D7%AA%D7%9B%D7%A9%D7%99%D7%A8%D7%99%D7%9D-%D7%95%D7%AA%D7%95%D7%A1%D7%A4%D7%99%D7%9D-%D7%9C%D7%90%D7%A7%D7%95%D7%95%D7%A8%D7%99%D7%95%D7%9D)  
   * [ תרופות דגים/אלמוגים](https://www.perfectreef.co.il/249826-%D7%AA%D7%A8%D7%95%D7%A4%D7%95%D7%AA-%D7%93%D7%92%D7%99%D7%9D-%D7%90%D7%9C%D7%9E%D7%95%D7%92%D7%99%D7%9D)  
   * [ מגנטים, סקרפרים וציוד ניקוי](https://www.perfectreef.co.il/248058-%D7%9E%D7%92%D7%A0%D7%98%D7%99%D7%9D-%D7%A1%D7%A7%D7%A8%D7%A4%D7%A8%D7%99%D7%9D-%D7%95%D7%A6%D7%99%D7%95%D7%93-%D7%A0%D7%99%D7%A7%D7%95%D7%99)  
   * [ גופי חימום ומדי חום](https://www.perfectreef.co.il/248065-%D7%92%D7%95%D7%A4%D7%99-%D7%97%D7%99%D7%9E%D7%95%D7%9D-%D7%95%D7%9E%D7%93%D7%99-%D7%97%D7%95%D7%9D)  
   * [ מקררים ומאווררי קירור](https://www.perfectreef.co.il/248066-%D7%9E%D7%A7%D7%A8%D7%A8%D7%99%D7%9D-%D7%95%D7%9E%D7%90%D7%95%D7%95%D7%A8%D7%A8%D7%99-%D7%A7%D7%99%D7%A8%D7%95%D7%A8)  
   * [ ערכות בדיקה](https://www.perfectreef.co.il/246276-%D7%A2%D7%A8%D7%9B%D7%95%D7%AA-%D7%91%D7%93%D7%99%D7%A7%D7%94)  
   * [ ציוד נלווה](https://www.perfectreef.co.il/246332-%D7%A6%D7%99%D7%95%D7%93-%D7%A0%D7%9C%D7%95%D7%95%D7%94)  
   * [ חומרי סינון לאקווריום](https://www.perfectreef.co.il/264646-%D7%97%D7%95%D7%9E%D7%A8%D7%99-%D7%A1%D7%99%D7%A0%D7%95%D7%9F-%D7%9C%D7%90%D7%A7%D7%95%D7%95%D7%A8%D7%99%D7%95%D7%9D)  
   * [ מערכות UV ואוזון](https://www.perfectreef.co.il/248070-%D7%9E%D7%A2%D7%A8%D7%9B%D7%95%D7%AA-UV-%D7%95%D7%90%D7%95%D7%96%D7%95%D7%9F)  
   * [ דקורציות](https://www.perfectreef.co.il/248069-%D7%93%D7%A7%D7%95%D7%A8%D7%A6%D7%99%D7%95%D7%AA)  
   * [ גופי תאורה](https://www.perfectreef.co.il/248394-%D7%92%D7%95%D7%A4%D7%99-%D7%AA%D7%90%D7%95%D7%A8%D7%94)  
   * [ סיליקון ודבקים לאקווריום](https://www.perfectreef.co.il/248398-%D7%A1%D7%99%D7%9C%D7%99%D7%A7%D7%95%D7%9F-%D7%95%D7%93%D7%91%D7%A7%D7%99%D7%9D-%D7%9C%D7%90%D7%A7%D7%95%D7%95%D7%A8%D7%99%D7%95%D7%9D)  
   * [ מצעים וחצצים](https://www.perfectreef.co.il/248811-%D7%9E%D7%A6%D7%A2%D7%99%D7%9D-%D7%95%D7%97%D7%A6%D7%A6%D7%99%D7%9D)  
   * [ מערכות אוסמוזה וציודן](https://www.perfectreef.co.il/248820-%D7%9E%D7%A2%D7%A8%D7%9B%D7%95%D7%AA-%D7%90%D7%95%D7%A1%D7%9E%D7%95%D7%96%D7%94-%D7%95%D7%A6%D7%99%D7%95%D7%93%D7%9F)  
   * [ מאכילים אוטומטיים](https://www.perfectreef.co.il/248821-%D7%9E%D7%90%D7%9B%D7%99%D7%9C%D7%99%D7%9D-%D7%90%D7%95%D7%98%D7%95%D7%9E%D7%98%D7%99%D7%99%D7%9D)  
   * [ צינורות גמישים ומחברים](https://www.perfectreef.co.il/248823-%D7%A6%D7%99%D7%A0%D7%95%D7%A8%D7%95%D7%AA-%D7%92%D7%9E%D7%99%D7%A9%D7%99%D7%9D-%D7%95%D7%9E%D7%97%D7%91%D7%A8%D7%99%D7%9D)  
   * [ משאבות מינון](https://www.perfectreef.co.il/295372-%D7%9E%D7%A9%D7%90%D7%91%D7%95%D7%AA-%D7%9E%D7%99%D7%A0%D7%95%D7%9F)  
   * [ שואבי רפש](https://www.perfectreef.co.il/248068-%D7%A9%D7%95%D7%90%D7%91%D7%99-%D7%A8%D7%A4%D7%A9)  
   * [ תאי השרצה, אקלום ומלכודות ](https://www.perfectreef.co.il/354094-%D7%AA%D7%90%D7%99-%D7%94%D7%A9%D7%A8%D7%A6%D7%94-%D7%90%D7%A7%D7%9C%D7%95%D7%9D-%D7%95%D7%9E%D7%9C%D7%9B%D7%95%D7%93%D7%95%D7%AA-)  
   * [ מערכות פיצוי אידוי ](https://www.perfectreef.co.il/252927-%D7%9E%D7%A2%D7%A8%D7%9B%D7%95%D7%AA-%D7%A4%D7%99%D7%A6%D7%95%D7%99-%D7%90%D7%99%D7%93%D7%95%D7%99-)  
   * [ חלקי צנרת PVC](https://www.perfectreef.co.il/248396-%D7%97%D7%9C%D7%A7%D7%99-%D7%A6%D7%A0%D7%A8%D7%AA-PVC)  
   * מחלקת מים מלוחים  
   * [ פורקי חלבונים וקולונות](https://www.perfectreef.co.il/246295-%D7%A4%D7%95%D7%A8%D7%A7%D7%99-%D7%97%D7%9C%D7%91%D7%95%D7%A0%D7%99%D7%9D-%D7%95%D7%A7%D7%95%D7%9C%D7%95%D7%A0%D7%95%D7%AA)  
   * [ מזונות לדגי ים ](https://www.perfectreef.co.il/247100-%D7%9E%D7%96%D7%95%D7%A0%D7%95%D7%AA-%D7%9C%D7%93%D7%92%D7%99-%D7%99%D7%9D-)  
   * [ תכשירים ותוספים למלוחים](https://www.perfectreef.co.il/246268-%D7%AA%D7%9B%D7%A9%D7%99%D7%A8%D7%99%D7%9D-%D7%95%D7%AA%D7%95%D7%A1%D7%A4%D7%99%D7%9D-%D7%9C%D7%9E%D7%9C%D7%95%D7%97%D7%99%D7%9D)  
   * [ מזונות אלמוגים וחסרי חוליות](https://www.perfectreef.co.il/734248-%D7%9E%D7%96%D7%95%D7%A0%D7%95%D7%AA-%D7%90%D7%9C%D7%9E%D7%95%D7%92%D7%99%D7%9D-%D7%95%D7%97%D7%A1%D7%A8%D7%99-%D7%97%D7%95%D7%9C%D7%99%D7%95%D7%AA)  
   * [ מלחים ](https://www.perfectreef.co.il/265540-%D7%9E%D7%9C%D7%97%D7%99%D7%9D-)  
   * [ מדי מליחות ועזרים למלוחים](https://www.perfectreef.co.il/248059-%D7%9E%D7%93%D7%99-%D7%9E%D7%9C%D7%99%D7%97%D7%95%D7%AA-%D7%95%D7%A2%D7%96%D7%A8%D7%99%D7%9D-%D7%9C%D7%9E%D7%9C%D7%95%D7%97%D7%99%D7%9D)  
   * [ סופחים למלוחים](https://www.perfectreef.co.il/265379-%D7%A1%D7%95%D7%A4%D7%97%D7%99%D7%9D-%D7%9C%D7%9E%D7%9C%D7%95%D7%97%D7%99%D7%9D)  
   * מחלקת מים מתוקים  
   * [ פילטרים פנימיים](https://www.perfectreef.co.il/247102-%D7%A4%D7%99%D7%9C%D7%98%D7%A8%D7%99%D7%9D-%D7%A4%D7%A0%D7%99%D7%9E%D7%99%D7%99%D7%9D)  
   * [ פילטרים חיצוניים](https://www.perfectreef.co.il/248060-%D7%A4%D7%99%D7%9C%D7%98%D7%A8%D7%99%D7%9D-%D7%97%D7%99%D7%A6%D7%95%D7%A0%D7%99%D7%99%D7%9D)  
   * [ מזונות דגים וחסרי חוליות](https://www.perfectreef.co.il/246280-%D7%9E%D7%96%D7%95%D7%A0%D7%95%D7%AA-%D7%93%D7%92%D7%99%D7%9D-%D7%95%D7%97%D7%A1%D7%A8%D7%99-%D7%97%D7%95%D7%9C%D7%99%D7%95%D7%AA)  
   * [ תכשירים ותוספים לאקווריום צמחיה ](https://www.perfectreef.co.il/246296-%D7%AA%D7%9B%D7%A9%D7%99%D7%A8%D7%99%D7%9D-%D7%95%D7%AA%D7%95%D7%A1%D7%A4%D7%99%D7%9D-%D7%9C%D7%90%D7%A7%D7%95%D7%95%D7%A8%D7%99%D7%95%D7%9D-%D7%A6%D7%9E%D7%97%D7%99%D7%94-)  
   * [ ציוד לאקווריום צמחיה](https://www.perfectreef.co.il/257470-%D7%A6%D7%99%D7%95%D7%93-%D7%9C%D7%90%D7%A7%D7%95%D7%95%D7%A8%D7%99%D7%95%D7%9D-%D7%A6%D7%9E%D7%97%D7%99%D7%94)  
   * [ ספוגים וחלקי חילוף לפילטרים](https://www.perfectreef.co.il/257284-%D7%A1%D7%A4%D7%95%D7%92%D7%99%D7%9D-%D7%95%D7%97%D7%9C%D7%A7%D7%99-%D7%97%D7%99%D7%9C%D7%95%D7%A3-%D7%9C%D7%A4%D7%99%D7%9C%D7%98%D7%A8%D7%99%D7%9D)  
   * [ חלקי חילוף לג'אוול](https://www.perfectreef.co.il/248062-%D7%97%D7%9C%D7%A7%D7%99-%D7%97%D7%99%D7%9C%D7%95%D7%A3-%D7%9C%D7%92-%D7%90%D7%95%D7%95%D7%9C)  
   * מחלקת בריכות נוי  
   * [ משאבות מים לבריכות](https://www.perfectreef.co.il/248072-%D7%9E%D7%A9%D7%90%D7%91%D7%95%D7%AA-%D7%9E%D7%99%D7%9D-%D7%9C%D7%91%D7%A8%D7%99%D7%9B%D7%95%D7%AA)  
   * [ בריכות נוי וציודם ](https://www.perfectreef.co.il/246300-%D7%91%D7%A8%D7%99%D7%9B%D7%95%D7%AA-%D7%A0%D7%95%D7%99-%D7%95%D7%A6%D7%99%D7%95%D7%93%D7%9D-)  
   * [ פילטרים לבריכות](https://www.perfectreef.co.il/248071-%D7%A4%D7%99%D7%9C%D7%98%D7%A8%D7%99%D7%9D-%D7%9C%D7%91%D7%A8%D7%99%D7%9B%D7%95%D7%AA)  
   * [ תאורות לבריכות](https://www.perfectreef.co.il/248073-%D7%AA%D7%90%D7%95%D7%A8%D7%95%D7%AA-%D7%9C%D7%91%D7%A8%D7%99%D7%9B%D7%95%D7%AA)  
   * [ תכשירים ותוספים לבריכות](https://www.perfectreef.co.il/252104-%D7%AA%D7%9B%D7%A9%D7%99%D7%A8%D7%99%D7%9D-%D7%95%D7%AA%D7%95%D7%A1%D7%A4%D7%99%D7%9D-%D7%9C%D7%91%D7%A8%D7%99%D7%9B%D7%95%D7%AA)  
   * [ מזונות דגי בריכה](https://www.perfectreef.co.il/254849-%D7%9E%D7%96%D7%95%D7%A0%D7%95%D7%AA-%D7%93%D7%92%D7%99-%D7%91%D7%A8%D7%99%D7%9B%D7%94)
* [כלבים](https://www.perfectreef.co.il/246271-%D7%9B%D7%9C%D7%91%D7%99%D7%9D)  
   * [ מזון יבש כלבים ](https://www.perfectreef.co.il/246279-%D7%9E%D7%96%D7%95%D7%9F-%D7%99%D7%91%D7%A9-%D7%9B%D7%9C%D7%91%D7%99%D7%9D-)  
   * [ מזון רפואי כלבים](https://www.perfectreef.co.il/246333-%D7%9E%D7%96%D7%95%D7%9F-%D7%A8%D7%A4%D7%95%D7%90%D7%99-%D7%9B%D7%9C%D7%91%D7%99%D7%9D)  
   * [ עצמות דחוסות וקשר כלבים](https://www.perfectreef.co.il/246299-%D7%A2%D7%A6%D7%9E%D7%95%D7%AA-%D7%93%D7%97%D7%95%D7%A1%D7%95%D7%AA-%D7%95%D7%A7%D7%A9%D7%A8-%D7%9B%D7%9C%D7%91%D7%99%D7%9D)  
   * [ חטיפי כלבים ](https://www.perfectreef.co.il/246286-%D7%97%D7%98%D7%99%D7%A4%D7%99-%D7%9B%D7%9C%D7%91%D7%99%D7%9D-)  
   * [ שימורים ומעדני כלבים](https://www.perfectreef.co.il/246273-%D7%A9%D7%99%D7%9E%D7%95%D7%A8%D7%99%D7%9D-%D7%95%D7%9E%D7%A2%D7%93%D7%A0%D7%99-%D7%9B%D7%9C%D7%91%D7%99%D7%9D)  
   * [ תוספי תזונה כלבים](https://www.perfectreef.co.il/246310-%D7%AA%D7%95%D7%A1%D7%A4%D7%99-%D7%AA%D7%96%D7%95%D7%A0%D7%94-%D7%9B%D7%9C%D7%91%D7%99%D7%9D)  
   * [ צעצועי כלבים](https://www.perfectreef.co.il/246334-%D7%A6%D7%A2%D7%A6%D7%95%D7%A2%D7%99-%D7%9B%D7%9C%D7%91%D7%99%D7%9D)  
   * [ כלי אוכל ושתיה כלבים](https://www.perfectreef.co.il/246298-%D7%9B%D7%9C%D7%99-%D7%90%D7%95%D7%9B%D7%9C-%D7%95%D7%A9%D7%AA%D7%99%D7%94-%D7%9B%D7%9C%D7%91%D7%99%D7%9D)  
   * [ מוצרי טיפוח לכלבים](https://www.perfectreef.co.il/246284-%D7%9E%D7%95%D7%A6%D7%A8%D7%99-%D7%98%D7%99%D7%A4%D7%95%D7%97-%D7%9C%D7%9B%D7%9C%D7%91%D7%99%D7%9D)  
   * [ מוצרי היגיינה לכלבים](https://www.perfectreef.co.il/272962-%D7%9E%D7%95%D7%A6%D7%A8%D7%99-%D7%94%D7%99%D7%92%D7%99%D7%99%D7%A0%D7%94-%D7%9C%D7%9B%D7%9C%D7%91%D7%99%D7%9D)  
   * [ מיטות ומזרני כלבים](https://www.perfectreef.co.il/246293-%D7%9E%D7%99%D7%98%D7%95%D7%AA-%D7%95%D7%9E%D7%96%D7%A8%D7%A0%D7%99-%D7%9B%D7%9C%D7%91%D7%99%D7%9D)  
   * [ קולרים ורצועות כלבים](https://www.perfectreef.co.il/246283-%D7%A7%D7%95%D7%9C%D7%A8%D7%99%D7%9D-%D7%95%D7%A8%D7%A6%D7%95%D7%A2%D7%95%D7%AA-%D7%9B%D7%9C%D7%91%D7%99%D7%9D)  
   * [ כלובי נשיאה ותיקי כלבים](https://www.perfectreef.co.il/246270-%D7%9B%D7%9C%D7%95%D7%91%D7%99-%D7%A0%D7%A9%D7%99%D7%90%D7%94-%D7%95%D7%AA%D7%99%D7%A7%D7%99-%D7%9B%D7%9C%D7%91%D7%99%D7%9D)  
   * [ ציוד ותכשירי אילוף ומשמעת כלבים](https://www.perfectreef.co.il/246312-%D7%A6%D7%99%D7%95%D7%93-%D7%95%D7%AA%D7%9B%D7%A9%D7%99%D7%A8%D7%99-%D7%90%D7%99%D7%9C%D7%95%D7%A3-%D7%95%D7%9E%D7%A9%D7%9E%D7%A2%D7%AA-%D7%9B%D7%9C%D7%91%D7%99%D7%9D)  
   * [ כלובים וגדרות אילוף כלבים](https://www.perfectreef.co.il/246337-%D7%9B%D7%9C%D7%95%D7%91%D7%99%D7%9D-%D7%95%D7%92%D7%93%D7%A8%D7%95%D7%AA-%D7%90%D7%99%D7%9C%D7%95%D7%A3-%D7%9B%D7%9C%D7%91%D7%99%D7%9D)  
   * [ מרחיקי כלבים ](https://www.perfectreef.co.il/246314-%D7%9E%D7%A8%D7%97%D7%99%D7%A7%D7%99-%D7%9B%D7%9C%D7%91%D7%99%D7%9D-)  
   * [ מוצרי הדברה כלבים](https://www.perfectreef.co.il/246285-%D7%9E%D7%95%D7%A6%D7%A8%D7%99-%D7%94%D7%93%D7%91%D7%A8%D7%94-%D7%9B%D7%9C%D7%91%D7%99%D7%9D)  
   * [ מזרקות מים לשתיה כלבים](https://www.perfectreef.co.il/262982-%D7%9E%D7%96%D7%A8%D7%A7%D7%95%D7%AA-%D7%9E%D7%99%D7%9D-%D7%9C%D7%A9%D7%AA%D7%99%D7%94-%D7%9B%D7%9C%D7%91%D7%99%D7%9D)
* [חתולים](https://www.perfectreef.co.il/246275-%D7%97%D7%AA%D7%95%D7%9C%D7%99%D7%9D)  
   * [ מזון יבש חתולים](https://www.perfectreef.co.il/246278-%D7%9E%D7%96%D7%95%D7%9F-%D7%99%D7%91%D7%A9-%D7%97%D7%AA%D7%95%D7%9C%D7%99%D7%9D)  
   * [ שימורים ומעדני חתולים](https://www.perfectreef.co.il/248504-%D7%A9%D7%99%D7%9E%D7%95%D7%A8%D7%99%D7%9D-%D7%95%D7%9E%D7%A2%D7%93%D7%A0%D7%99-%D7%97%D7%AA%D7%95%D7%9C%D7%99%D7%9D)  
   * [ מוצרי הדברה לחתולים](https://www.perfectreef.co.il/256442-%D7%9E%D7%95%D7%A6%D7%A8%D7%99-%D7%94%D7%93%D7%91%D7%A8%D7%94-%D7%9C%D7%97%D7%AA%D7%95%D7%9C%D7%99%D7%9D)  
   * [ חול חתולים ](https://www.perfectreef.co.il/246294-%D7%97%D7%95%D7%9C-%D7%97%D7%AA%D7%95%D7%9C%D7%99%D7%9D-)  
   * [ שירותי חתולים](https://www.perfectreef.co.il/246307-%D7%A9%D7%99%D7%A8%D7%95%D7%AA%D7%99-%D7%97%D7%AA%D7%95%D7%9C%D7%99%D7%9D)  
   * [ מגרדות חתולים](https://www.perfectreef.co.il/246289-%D7%9E%D7%92%D7%A8%D7%93%D7%95%D7%AA-%D7%97%D7%AA%D7%95%D7%9C%D7%99%D7%9D)  
   * [ חטיפי חתולים](https://www.perfectreef.co.il/246321-%D7%97%D7%98%D7%99%D7%A4%D7%99-%D7%97%D7%AA%D7%95%D7%9C%D7%99%D7%9D)  
   * [ תוספי חתולים](https://www.perfectreef.co.il/248179-%D7%AA%D7%95%D7%A1%D7%A4%D7%99-%D7%97%D7%AA%D7%95%D7%9C%D7%99%D7%9D)  
   * [ מוצרי היגיינה וטיפוח חתולים](https://www.perfectreef.co.il/248229-%D7%9E%D7%95%D7%A6%D7%A8%D7%99-%D7%94%D7%99%D7%92%D7%99%D7%99%D7%A0%D7%94-%D7%95%D7%98%D7%99%D7%A4%D7%95%D7%97-%D7%97%D7%AA%D7%95%D7%9C%D7%99%D7%9D)  
   * [ קולרי חתולים](https://www.perfectreef.co.il/246325-%D7%A7%D7%95%D7%9C%D7%A8%D7%99-%D7%97%D7%AA%D7%95%D7%9C%D7%99%D7%9D)  
   * [ צעצועי חתולים](https://www.perfectreef.co.il/246303-%D7%A6%D7%A2%D7%A6%D7%95%D7%A2%D7%99-%D7%97%D7%AA%D7%95%D7%9C%D7%99%D7%9D)  
   * [ מנשאות וכלובי חתולים](https://www.perfectreef.co.il/246297-%D7%9E%D7%A0%D7%A9%D7%90%D7%95%D7%AA-%D7%95%D7%9B%D7%9C%D7%95%D7%91%D7%99-%D7%97%D7%AA%D7%95%D7%9C%D7%99%D7%9D)  
   * [ כלי אוכל ושתיה חתולים](https://www.perfectreef.co.il/246274-%D7%9B%D7%9C%D7%99-%D7%90%D7%95%D7%9B%D7%9C-%D7%95%D7%A9%D7%AA%D7%99%D7%94-%D7%97%D7%AA%D7%95%D7%9C%D7%99%D7%9D)  
   * [ מרחיקי חתולים ](https://www.perfectreef.co.il/246326-%D7%9E%D7%A8%D7%97%D7%99%D7%A7%D7%99-%D7%97%D7%AA%D7%95%D7%9C%D7%99%D7%9D-)  
   * [ מיטות ומזרני חתולים](https://www.perfectreef.co.il/246328-%D7%9E%D7%99%D7%98%D7%95%D7%AA-%D7%95%D7%9E%D7%96%D7%A8%D7%A0%D7%99-%D7%97%D7%AA%D7%95%D7%9C%D7%99%D7%9D)  
   * [ מזון רפואי חתולים ](https://www.perfectreef.co.il/246327-%D7%9E%D7%96%D7%95%D7%9F-%D7%A8%D7%A4%D7%95%D7%90%D7%99-%D7%97%D7%AA%D7%95%D7%9C%D7%99%D7%9D-)  
   * [ מזרקות מים לשתיה לחתולים](https://www.perfectreef.co.il/262932-%D7%9E%D7%96%D7%A8%D7%A7%D7%95%D7%AA-%D7%9E%D7%99%D7%9D-%D7%9C%D7%A9%D7%AA%D7%99%D7%94-%D7%9C%D7%97%D7%AA%D7%95%D7%9C%D7%99%D7%9D)
* [ציפורים ](https://www.perfectreef.co.il/246282-%D7%A6%D7%99%D7%A4%D7%95%D7%A8%D7%99%D7%9D-)  
   * [ כלובי ציפורים](https://www.perfectreef.co.il/248235-%D7%9B%D7%9C%D7%95%D7%91%D7%99-%D7%A6%D7%99%D7%A4%D7%95%D7%A8%D7%99%D7%9D)  
   * [ מזון ציפורים](https://www.perfectreef.co.il/246292-%D7%9E%D7%96%D7%95%D7%9F-%D7%A6%D7%99%D7%A4%D7%95%D7%A8%D7%99%D7%9D)  
   * [  חטיפי ציפורים](https://www.perfectreef.co.il/248164--%D7%97%D7%98%D7%99%D7%A4%D7%99-%D7%A6%D7%99%D7%A4%D7%95%D7%A8%D7%99%D7%9D)  
   * [ תוספי ציפורים](https://www.perfectreef.co.il/246323-%D7%AA%D7%95%D7%A1%D7%A4%D7%99-%D7%A6%D7%99%D7%A4%D7%95%D7%A8%D7%99%D7%9D)  
   * [ צעצועים ואביזרי ציפורים](https://www.perfectreef.co.il/246281-%D7%A6%D7%A2%D7%A6%D7%95%D7%A2%D7%99%D7%9D-%D7%95%D7%90%D7%91%D7%99%D7%96%D7%A8%D7%99-%D7%A6%D7%99%D7%A4%D7%95%D7%A8%D7%99%D7%9D)
* [מכרסמים ](https://www.perfectreef.co.il/246288-%D7%9E%D7%9B%D7%A8%D7%A1%D7%9E%D7%99%D7%9D-)  
   * [ כלובי מכרסמים](https://www.perfectreef.co.il/246291-%D7%9B%D7%9C%D7%95%D7%91%D7%99-%D7%9E%D7%9B%D7%A8%D7%A1%D7%9E%D7%99%D7%9D)  
   * [ חטיפים ותוספים מכרסמים](https://www.perfectreef.co.il/246287-%D7%97%D7%98%D7%99%D7%A4%D7%99%D7%9D-%D7%95%D7%AA%D7%95%D7%A1%D7%A4%D7%99%D7%9D-%D7%9E%D7%9B%D7%A8%D7%A1%D7%9E%D7%99%D7%9D)  
   * [ בתי מחסה למכרסמים](https://www.perfectreef.co.il/348540-%D7%91%D7%AA%D7%99-%D7%9E%D7%97%D7%A1%D7%94-%D7%9C%D7%9E%D7%9B%D7%A8%D7%A1%D7%9E%D7%99%D7%9D)  
   * [ כלי אוכל ושתיה למכרסמים](https://www.perfectreef.co.il/349107-%D7%9B%D7%9C%D7%99-%D7%90%D7%95%D7%9B%D7%9C-%D7%95%D7%A9%D7%AA%D7%99%D7%94-%D7%9C%D7%9E%D7%9B%D7%A8%D7%A1%D7%9E%D7%99%D7%9D)  
   * [ מזון מכרסמים](https://www.perfectreef.co.il/248168-%D7%9E%D7%96%D7%95%D7%9F-%D7%9E%D7%9B%D7%A8%D7%A1%D7%9E%D7%99%D7%9D)  
   * [ מצע מכרסמים ](https://www.perfectreef.co.il/246308-%D7%9E%D7%A6%D7%A2-%D7%9E%D7%9B%D7%A8%D7%A1%D7%9E%D7%99%D7%9D-)  
   * [ צעצועי מכרסמים](https://www.perfectreef.co.il/246324-%D7%A6%D7%A2%D7%A6%D7%95%D7%A2%D7%99-%D7%9E%D7%9B%D7%A8%D7%A1%D7%9E%D7%99%D7%9D)  
   * [ מוצרי היגיינה וטיפוח מכרסמים](https://www.perfectreef.co.il/248230-%D7%9E%D7%95%D7%A6%D7%A8%D7%99-%D7%94%D7%99%D7%92%D7%99%D7%99%D7%A0%D7%94-%D7%95%D7%98%D7%99%D7%A4%D7%95%D7%97-%D7%9E%D7%9B%D7%A8%D7%A1%D7%9E%D7%99%D7%9D)
* [זוחלים ](https://www.perfectreef.co.il/246306-%D7%96%D7%95%D7%97%D7%9C%D7%99%D7%9D-)  
   * [ טרריומים ופולידריומים](https://www.perfectreef.co.il/246305-%D7%98%D7%A8%D7%A8%D7%99%D7%95%D7%9E%D7%99%D7%9D-%D7%95%D7%A4%D7%95%D7%9C%D7%99%D7%93%D7%A8%D7%99%D7%95%D7%9E%D7%99%D7%9D)  
   * [ מצע זוחלים](https://www.perfectreef.co.il/246329-%D7%9E%D7%A6%D7%A2-%D7%96%D7%95%D7%97%D7%9C%D7%99%D7%9D)  
   * [ שטיחים אקולוגיים](https://www.perfectreef.co.il/261752-%D7%A9%D7%98%D7%99%D7%97%D7%99%D7%9D-%D7%90%D7%A7%D7%95%D7%9C%D7%95%D7%92%D7%99%D7%99%D7%9D)  
   * [ תאורת זוחלים](https://www.perfectreef.co.il/246313-%D7%AA%D7%90%D7%95%D7%A8%D7%AA-%D7%96%D7%95%D7%97%D7%9C%D7%99%D7%9D)  
   * [ כלי האכלה זוחלים](https://www.perfectreef.co.il/248097-%D7%9B%D7%9C%D7%99-%D7%94%D7%90%D7%9B%D7%9C%D7%94-%D7%96%D7%95%D7%97%D7%9C%D7%99%D7%9D)  
   * [ דקורציות ומחסה לזוחלים](https://www.perfectreef.co.il/246335-%D7%93%D7%A7%D7%95%D7%A8%D7%A6%D7%99%D7%95%D7%AA-%D7%95%D7%9E%D7%97%D7%A1%D7%94-%D7%9C%D7%96%D7%95%D7%97%D7%9C%D7%99%D7%9D)  
   * [ מוצרי חימום זוחלים](https://www.perfectreef.co.il/246336-%D7%9E%D7%95%D7%A6%D7%A8%D7%99-%D7%97%D7%99%D7%9E%D7%95%D7%9D-%D7%96%D7%95%D7%97%D7%9C%D7%99%D7%9D)  
   * [ אבני חימום לזוחלים](https://www.perfectreef.co.il/257998-%D7%90%D7%91%D7%A0%D7%99-%D7%97%D7%99%D7%9E%D7%95%D7%9D-%D7%9C%D7%96%D7%95%D7%97%D7%9C%D7%99%D7%9D)  
   * [ ציוד זוחלים ](https://www.perfectreef.co.il/246331-%D7%A6%D7%99%D7%95%D7%93-%D7%96%D7%95%D7%97%D7%9C%D7%99%D7%9D-)  
   * [ מדי לחות וטמפרטורה ](https://www.perfectreef.co.il/276824-%D7%9E%D7%93%D7%99-%D7%9C%D7%97%D7%95%D7%AA-%D7%95%D7%98%D7%9E%D7%A4%D7%A8%D7%98%D7%95%D7%A8%D7%94-)
* [אינדקס אלמוגים](https://www.perfectreef.co.il/472345-%D7%90%D7%99%D7%A0%D7%93%D7%A7%D7%A1-%D7%90%D7%9C%D7%9E%D7%95%D7%92%D7%99%D7%9D)  
   * [ אלמוגים רכים](https://www.perfectreef.co.il/477638-%D7%90%D7%9C%D7%9E%D7%95%D7%92%D7%99%D7%9D-%D7%A8%D7%9B%D7%99%D7%9D)  
   * [ אלמוגי SPS](https://www.perfectreef.co.il/479422-%D7%90%D7%9C%D7%9E%D7%95%D7%92%D7%99-SPS)  
   * [ אלמוגי LPS](https://www.perfectreef.co.il/482427-%D7%90%D7%9C%D7%9E%D7%95%D7%92%D7%99-LPS)  
   * [ פטריות וזאונטידים](https://www.perfectreef.co.il/490264-%D7%A4%D7%98%D7%A8%D7%99%D7%95%D7%AA-%D7%95%D7%96%D7%90%D7%95%D7%A0%D7%98%D7%99%D7%93%D7%99%D7%9D)
* אינדקס דגי נוי  
   * [ דגי קרב](https://www.perfectreef.co.il/249896-%D7%93%D7%92%D7%99-%D7%A7%D7%A8%D7%91)  
   * [ גרזנוניים](https://www.perfectreef.co.il/264505-%D7%92%D7%A8%D7%96%D7%A0%D7%95%D7%A0%D7%99%D7%99%D7%9D)  
   * [ בוטיות](https://www.perfectreef.co.il/252475-%D7%91%D7%95%D7%98%D7%99%D7%95%D7%AA)  
   * [ קיליפיש](https://www.perfectreef.co.il/264508-%D7%A7%D7%99%D7%9C%D7%99%D7%A4%D7%99%D7%A9)  
   * [ גלופיש](https://www.perfectreef.co.il/264511-%D7%92%D7%9C%D7%95%D7%A4%D7%99%D7%A9)  
   * [ קשתות](https://www.perfectreef.co.il/252486-%D7%A7%D7%A9%D7%AA%D7%95%D7%AA)  
   * [ פלקו](https://www.perfectreef.co.il/253006-%D7%A4%D7%9C%D7%A7%D7%95)  
   * [ רב סנפיר](https://www.perfectreef.co.il/250198-%D7%A8%D7%91-%D7%A1%D7%A0%D7%A4%D7%99%D7%A8)  
   * [ ציקלידים אפריקאים](https://www.perfectreef.co.il/248694-%D7%A6%D7%99%D7%A7%D7%9C%D7%99%D7%93%D7%99%D7%9D-%D7%90%D7%A4%D7%A8%D7%99%D7%A7%D7%90%D7%99%D7%9D)  
   * [ דיסקוסים](https://www.perfectreef.co.il/248704-%D7%93%D7%99%D7%A1%D7%A7%D7%95%D7%A1%D7%99%D7%9D)  
   * [ צלופחים וסכינים](https://www.perfectreef.co.il/248705-%D7%A6%D7%9C%D7%95%D7%A4%D7%97%D7%99%D7%9D-%D7%95%D7%A1%D7%9B%D7%99%D7%A0%D7%99%D7%9D)  
   * [ משריצי חיים](https://www.perfectreef.co.il/248706-%D7%9E%D7%A9%D7%A8%D7%99%D7%A6%D7%99-%D7%97%D7%99%D7%99%D7%9D)  
   * [ קורידורסים](https://www.perfectreef.co.il/248707-%D7%A7%D7%95%D7%A8%D7%99%D7%93%D7%95%D7%A8%D7%A1%D7%99%D7%9D)  
   * [ סקלארים](https://www.perfectreef.co.il/248708-%D7%A1%D7%A7%D7%9C%D7%90%D7%A8%D7%99%D7%9D)  
   * [ ציקלידים אמריקאים](https://www.perfectreef.co.il/248709-%D7%A6%D7%99%D7%A7%D7%9C%D7%99%D7%93%D7%99%D7%9D-%D7%90%D7%9E%D7%A8%D7%99%D7%A7%D7%90%D7%99%D7%9D)  
   * [ דגי טטרה](https://www.perfectreef.co.il/248710-%D7%93%D7%92%D7%99-%D7%98%D7%98%D7%A8%D7%94)  
   * [ גורמים](https://www.perfectreef.co.il/252039-%D7%92%D7%95%D7%A8%D7%9E%D7%99%D7%9D)  
   * [ חתוליים](https://www.perfectreef.co.il/250765-%D7%97%D7%AA%D7%95%D7%9C%D7%99%D7%99%D7%9D)  
   * [ כרישים](https://www.perfectreef.co.il/251797-%D7%9B%D7%A8%D7%99%D7%A9%D7%99%D7%9D)  
   * [ רזבורות](https://www.perfectreef.co.il/252640-%D7%A8%D7%96%D7%91%D7%95%D7%A8%D7%95%D7%AA)  
   * [ דניוס ומינואס](https://www.perfectreef.co.il/264687-%D7%93%D7%A0%D7%99%D7%95%D7%A1-%D7%95%D7%9E%D7%99%D7%A0%D7%95%D7%90%D7%A1)  
   * [ ארואנות](https://www.perfectreef.co.il/252670-%D7%90%D7%A8%D7%95%D7%90%D7%A0%D7%95%D7%AA)  
   * [ דגי מים מתוקים למתחילים](https://www.perfectreef.co.il/264310-%D7%93%D7%92%D7%99-%D7%9E%D7%99%D7%9D-%D7%9E%D7%AA%D7%95%D7%A7%D7%99%D7%9D-%D7%9C%D7%9E%D7%AA%D7%97%D7%99%D7%9C%D7%99%D7%9D)  
   * [ נפוחתיים](https://www.perfectreef.co.il/460960-%D7%A0%D7%A4%D7%95%D7%97%D7%AA%D7%99%D7%99%D7%9D)  
   * [ מים מליחים](https://www.perfectreef.co.il/460996-%D7%9E%D7%99%D7%9D-%D7%9E%D7%9C%D7%99%D7%97%D7%99%D7%9D)
* [אינדקס מים מלוחים](https://www.perfectreef.co.il/248914-%D7%90%D7%99%D7%A0%D7%93%D7%A7%D7%A1-%D7%9E%D7%99%D7%9D-%D7%9E%D7%9C%D7%95%D7%97%D7%99%D7%9D)  
   * [ עטלפים](https://www.perfectreef.co.il/254019-%D7%A2%D7%98%D7%9C%D7%A4%D7%99%D7%9D)  
   * [ ראביט פיש](https://www.perfectreef.co.il/254237-%D7%A8%D7%90%D7%91%D7%99%D7%98-%D7%A4%D7%99%D7%A9)  
   * [ דגי קופסה ופרה ](https://www.perfectreef.co.il/254495-%D7%93%D7%92%D7%99-%D7%A7%D7%95%D7%A4%D7%A1%D7%94-%D7%95%D7%A4%D7%A8%D7%94-)  
   * [ פסאודוכרומיסים צבעוניים ](https://www.perfectreef.co.il/254570-%D7%A4%D7%A1%D7%90%D7%95%D7%93%D7%95%D7%9B%D7%A8%D7%95%D7%9E%D7%99%D7%A1%D7%99%D7%9D-%D7%A6%D7%91%D7%A2%D7%95%D7%A0%D7%99%D7%99%D7%9D-)  
   * [ שושנונים](https://www.perfectreef.co.il/249452-%D7%A9%D7%95%D7%A9%D7%A0%D7%95%D7%A0%D7%99%D7%9D)  
   * [ אנגלים ננסיים](https://www.perfectreef.co.il/249453-%D7%90%D7%A0%D7%92%D7%9C%D7%99%D7%9D-%D7%A0%D7%A0%D7%A1%D7%99%D7%99%D7%9D)  
   * [ פזיות ](https://www.perfectreef.co.il/249454-%D7%A4%D7%96%D7%99%D7%95%D7%AA-)  
   * [ בלנים](https://www.perfectreef.co.il/249455-%D7%91%D7%9C%D7%A0%D7%99%D7%9D)  
   * [ פרפרונים](https://www.perfectreef.co.il/249456-%D7%A4%D7%A8%D7%A4%D7%A8%D7%95%D7%A0%D7%99%D7%9D)  
   * [ אבובוניים](https://www.perfectreef.co.il/254065-%D7%90%D7%91%D7%95%D7%91%D7%95%D7%A0%D7%99%D7%99%D7%9D)  
   * [ קרדינלים](https://www.perfectreef.co.il/249458-%D7%A7%D7%A8%D7%93%D7%99%D7%A0%D7%9C%D7%99%D7%9D)  
   * [ אלמוגיות](https://www.perfectreef.co.il/249459-%D7%90%D7%9C%D7%9E%D7%95%D7%92%D7%99%D7%95%D7%AA)  
   * [ דרגונטים](https://www.perfectreef.co.il/249460-%D7%93%D7%A8%D7%92%D7%95%D7%A0%D7%98%D7%99%D7%9D)  
   * [ מורנות](https://www.perfectreef.co.il/249461-%D7%9E%D7%95%D7%A8%D7%A0%D7%95%D7%AA)  
   * [ גובים](https://www.perfectreef.co.il/249462-%D7%92%D7%95%D7%91%D7%99%D7%9D)  
   * [ לוקוסים](https://www.perfectreef.co.il/249463-%D7%9C%D7%95%D7%A7%D7%95%D7%A1%D7%99%D7%9D)  
   * [ הוק-פישים](https://www.perfectreef.co.il/249464-%D7%94%D7%95%D7%A7-%D7%A4%D7%99%D7%A9%D7%99%D7%9D)  
   * [ נתחנים ](https://www.perfectreef.co.il/249466-%D7%A0%D7%AA%D7%97%D7%A0%D7%99%D7%9D-)  
   * [ נצרנים](https://www.perfectreef.co.il/249467-%D7%A0%D7%A6%D7%A8%D7%A0%D7%99%D7%9D)  
   * [ אנגלים](https://www.perfectreef.co.il/248956-%D7%90%D7%A0%D7%92%D7%9C%D7%99%D7%9D)  
   * [ חד קוציים](https://www.perfectreef.co.il/254928-%D7%97%D7%93-%D7%A7%D7%95%D7%A6%D7%99%D7%99%D7%9D)  
   * [ ואראס ותוכינונים](https://www.perfectreef.co.il/254172-%D7%95%D7%90%D7%A8%D7%90%D7%A1-%D7%95%D7%AA%D7%95%D7%9B%D7%99%D7%A0%D7%95%D7%A0%D7%99%D7%9D)  
   * [ כרומיסים](https://www.perfectreef.co.il/249457-%D7%9B%D7%A8%D7%95%D7%9E%D7%99%D7%A1%D7%99%D7%9D)  
   * [ דגי מים מלוחים למתחילים](https://www.perfectreef.co.il/264340-%D7%93%D7%92%D7%99-%D7%9E%D7%99%D7%9D-%D7%9E%D7%9C%D7%95%D7%97%D7%99%D7%9D-%D7%9C%D7%9E%D7%AA%D7%97%D7%99%D7%9C%D7%99%D7%9D)
* [אינדקס צמחי מים](https://www.perfectreef.co.il/492970-%D7%90%D7%99%D7%A0%D7%93%D7%A7%D7%A1-%D7%A6%D7%9E%D7%97%D7%99-%D7%9E%D7%99%D7%9D)  
   * [ צמחי הייטק](https://www.perfectreef.co.il/492975-%D7%A6%D7%9E%D7%97%D7%99-%D7%94%D7%99%D7%99%D7%98%D7%A7)  
   * [ צמחי לאוטק](https://www.perfectreef.co.il/492983-%D7%A6%D7%9E%D7%97%D7%99-%D7%9C%D7%90%D7%95%D7%98%D7%A7)  
   * [ צמחי בריכה](https://www.perfectreef.co.il/492998-%D7%A6%D7%9E%D7%97%D7%99-%D7%91%D7%A8%D7%99%D7%9B%D7%94)

[ 03-7443033 ](tel:03-7443033) 

לברורים והזמנות חייגו:

X

* רוקן עגלה

* היי,
* [התחבר](https://www.perfectreef.co.il/customer%5Flogin)
* [הרשמת לקוחות](https://www.perfectreef.co.il/customer%5Fsignup)

0  מוצרים 

 סה"כ ₪0.00 

כאן מופיעים כל המוצרים שכרגע נמצאים בעגלת הקניות שלכם

המשך בקניות

לקופה 

* [דף הבית](https://www.perfectreef.co.il/  
)
* אינדקס דגי נוי

# אינדקס דגי נוי 

בעולם האקווריומים ובריכות הנוי, מגוון הדגים הזמין יכול להיות מרשים כמו גם מבלבל. מדגי בריכה שקטים ועד לדגים מיוחדים שמוסיפים צבע וחיות לכל מיכל, כל חובב דגי נוי יכול למצוא את הדגים המושלמים לסביבתו בין אם לאקווריום ביתי או לבריכות נוי.

****\* אנו לא מבצעים משלוחי דגים וצמחי מים \***

## דגי נוי: מגוון ויופי

דגי נוי הם בחירה פופולרית בקרב חובבי האקווריומים ובריכות נוי, משום שהם מוסיפים יופי וחן לכל סביבה מימית. דגים אלו מגיעים במגוון רחב של צבעים, גדלים ותכונות, מה שהופך אותם למרכז עניין בכל אקווריום או בריכה.

### דגי בריכות נוי: פתרון לגינות

דגי בריכה נוי אידיאליים למי שברשותו בריכה חיצונית ומעוניין להוסיף חיים ועניין חזותי לגינה או לחצר. דגי “קוי” ו"דגי זהב" הם דוגמאות נפוצות של דגי בריכות המתאימים לתנאים חיצוניים ומוסיפים צבע ותנועה לנוף הגינה.

לעיונכם קטלוג דגים באתר שלנו, לכל מי שמחפש דגים מיוחדים ורוצה להכיר טוב יותר את האפשרויות השונות לפני שבוחר דגים לאקווריום או לבריכה. הקטלוג מפורט ומספק מידע על התנהגות הדגים, דרישות תחזוקה וכל המידע החיוני עבור בחירת דגי בריכה ונוי.

פרפקט ריף היא אחת מחברות היבוא המובילות בארץ בתחום דגי הנוי, בעלת מערכות תפעול ענק שמאפשרות לנו להציע מלאי עשיר ומגוון של דגי נוי צמחים אלמוגים וחסרי חוליות שמגיעים מכל קצוות עולם מאוקיאנוסים אגמים נהרות וממקורות טבעיים. כאשר המשלוחים מגיעים, הדגים עוברים תהליך טיפולי מקיף להשמדת טפילים פנימיים וחיצוניים, כדי להבטיח שתקבלו דגים במצב בריאות מעולה. בפרפקט ריף אנו מבצעים יבוא עצמאי של הדגים ומחדשים את מלאי הדגים באופן שבועי, כדי להעניק ללקוחותינו את המיטב.

קרא עוד...

[נוספו לאחרונה](?order=down%5Fcreated%5Fat) 

_בחרת לסנן לפי:_ **[X](/ "בטל סינון")  אינדקס דגי נוי** 

**סינונים נוספים** 

[טווח מחירים](#group-price "Click to switch") 

**אינדקס דגי נוי** 

[ ![](https://d3m9l0v76dty0.cloudfront.net/system/photos/680490/original/933757a5d7a3f8d07f9f958392c76f9b.png)  דגי קרב ](/249896-%D7%93%D7%92%D7%99-%D7%A7%D7%A8%D7%91) 

[ ![](https://d3m9l0v76dty0.cloudfront.net/system/photos/727120/original/64a34efecd3bfcbee37de7bed7958df8.png)  גרזנוניים ](/264505-%D7%92%D7%A8%D7%96%D7%A0%D7%95%D7%A0%D7%99%D7%99%D7%9D) 

[ ![](https://d3m9l0v76dty0.cloudfront.net/system/photos/688677/original/f69c950124a75c55badf0d772a471779.png)  בוטיות ](/252475-%D7%91%D7%95%D7%98%D7%99%D7%95%D7%AA) 

[ ![](https://d3m9l0v76dty0.cloudfront.net/system/photos/727145/original/874919f57abe07b123325bd9dbd96526.png)  קיליפיש ](/264508-%D7%A7%D7%99%D7%9C%D7%99%D7%A4%D7%99%D7%A9) 

[ ![](https://d3m9l0v76dty0.cloudfront.net/system/photos/727188/original/985ebe85fc63a200611585cd08ecbb85.png)  גלופיש ](/264511-%D7%92%D7%9C%D7%95%D7%A4%D7%99%D7%A9) 

[ ![](https://d3m9l0v76dty0.cloudfront.net/system/photos/688793/original/51b44ed34773d0cf05ab3b39ad8f07aa.png)  קשתות ](/252486-%D7%A7%D7%A9%D7%AA%D7%95%D7%AA) 

[ ![](https://d3m9l0v76dty0.cloudfront.net/system/photos/691193/original/29f3c9e63c0ef687ad617773df47d2d7.png)  פלקו ](/253006-%D7%A4%D7%9C%D7%A7%D7%95) 

[ ![](https://d3m9l0v76dty0.cloudfront.net/system/photos/681923/original/66570f7985c092e3fd907afdb595387e.png)  רב סנפיר ](/250198-%D7%A8%D7%91-%D7%A1%D7%A0%D7%A4%D7%99%D7%A8) 

[ ![](https://d3m9l0v76dty0.cloudfront.net/system/photos/678250/original/a52fcb8344ad5ddbe4edbd0124eaecac.png)  ציקלידים אפריקאים ](/248694-%D7%A6%D7%99%D7%A7%D7%9C%D7%99%D7%93%D7%99%D7%9D-%D7%90%D7%A4%D7%A8%D7%99%D7%A7%D7%90%D7%99%D7%9D) 

[ ![](https://d3m9l0v76dty0.cloudfront.net/system/photos/678245/original/0fe7f1d65dfe556b050f43f3d013ecb0.png)  דיסקוסים ](/248704-%D7%93%D7%99%D7%A1%D7%A7%D7%95%D7%A1%D7%99%D7%9D) 

[ ![](https://d3m9l0v76dty0.cloudfront.net/system/photos/678490/original/78abb30625203ba384fd12ab008b6fd6.png)  צלופחים וסכינים ](/248705-%D7%A6%D7%9C%D7%95%D7%A4%D7%97%D7%99%D7%9D-%D7%95%D7%A1%D7%9B%D7%99%D7%A0%D7%99%D7%9D) 

[ ![](https://d3m9l0v76dty0.cloudfront.net/system/photos/678633/original/c52bd8c31c9fbddf658a844119ba32c6.png)  משריצי חיים ](/248706-%D7%9E%D7%A9%D7%A8%D7%99%D7%A6%D7%99-%D7%97%D7%99%D7%99%D7%9D) 

[ ![](https://d3m9l0v76dty0.cloudfront.net/system/photos/676385/original/6b95dd739d1501f936dbbf2e25bef86a.png)  קורידורסים ](/248707-%D7%A7%D7%95%D7%A8%D7%99%D7%93%D7%95%D7%A8%D7%A1%D7%99%D7%9D) 

[ ![](https://d3m9l0v76dty0.cloudfront.net/system/photos/679190/original/570373c0e3a34f3097751a343a6f0200.png)  סקלארים ](/248708-%D7%A1%D7%A7%D7%9C%D7%90%D7%A8%D7%99%D7%9D) 

[ ![](https://d3m9l0v76dty0.cloudfront.net/system/photos/680077/original/763b6118fdf892fda181fc778f14ad2a.png)  ציקלידים אמריקאים ](/248709-%D7%A6%D7%99%D7%A7%D7%9C%D7%99%D7%93%D7%99%D7%9D-%D7%90%D7%9E%D7%A8%D7%99%D7%A7%D7%90%D7%99%D7%9D) 

[ ![](https://d3m9l0v76dty0.cloudfront.net/system/photos/680084/original/8bebf29b39ebd48ed1842173cbe0c262.png)  דגי טטרה ](/248710-%D7%93%D7%92%D7%99-%D7%98%D7%98%D7%A8%D7%94) 

[ ![](https://d3m9l0v76dty0.cloudfront.net/system/photos/689207/original/61781f25398239c6eb072c2df6ed79ec.png)  גורמים ](/252039-%D7%92%D7%95%D7%A8%D7%9E%D7%99%D7%9D) 

[ ![](https://d3m9l0v76dty0.cloudfront.net/system/photos/683366/original/23a0d3af4b532539bd9f1af1ca9594df.png)  חתוליים ](/250765-%D7%97%D7%AA%D7%95%D7%9C%D7%99%D7%99%D7%9D) 

[ ![](https://d3m9l0v76dty0.cloudfront.net/system/photos/688585/original/08536a3a185c50751e30dc5dfdc0a9ce.png)  כרישים ](/251797-%D7%9B%D7%A8%D7%99%D7%A9%D7%99%D7%9D) 

[ ![](https://d3m9l0v76dty0.cloudfront.net/system/photos/689417/original/c1bda3b8413e2be036073bb3d22ff1d2.png)  רזבורות ](/252640-%D7%A8%D7%96%D7%91%D7%95%D7%A8%D7%95%D7%AA) 

[ ![](https://d3m9l0v76dty0.cloudfront.net/system/photos/727740/original/f5d9c12265c922d4c6961abc36ba322d.png)  דניוס ומינואס ](/264687-%D7%93%D7%A0%D7%99%D7%95%D7%A1-%D7%95%D7%9E%D7%99%D7%A0%D7%95%D7%90%D7%A1) 

[ ![](https://d3m9l0v76dty0.cloudfront.net/system/photos/690233/original/ec60925ec23dd994dffcf8ae17ce6dbe.png)  ארואנות ](/252670-%D7%90%D7%A8%D7%95%D7%90%D7%A0%D7%95%D7%AA) 

[ ![](https://d3m9l0v76dty0.cloudfront.net/system/photos/726842/original/5951f76750a38d4f235f3cb7e901a15d.png)  דגי מים מתוקים למתחילים ](/264310-%D7%93%D7%92%D7%99-%D7%9E%D7%99%D7%9D-%D7%9E%D7%AA%D7%95%D7%A7%D7%99%D7%9D-%D7%9C%D7%9E%D7%AA%D7%97%D7%99%D7%9C%D7%99%D7%9D) 

[ ![](https://d3m9l0v76dty0.cloudfront.net/system/photos/888472/original/f71c0ac667324eac2fc59b58f64681e0.png)  נפוחתיים ](/460960-%D7%A0%D7%A4%D7%95%D7%97%D7%AA%D7%99%D7%99%D7%9D) 

[ ![](https://d3m9l0v76dty0.cloudfront.net/system/photos/888502/medium/ba9596a7de884528a06e1354b293b4ff.png)  מים מליחים ](/460996-%D7%9E%D7%99%D7%9D-%D7%9E%D7%9C%D7%99%D7%97%D7%99%D7%9D) 

[ ](  /items/4725261-%D7%98%D7%A8%D7%99%D7%A7%D7%95%D7%98%D7%99-Benthochromis-Tricoti
)

[  טריקוטי-Benthochromis Tricoti ](  /items/4725261-%D7%98%D7%A8%D7%99%D7%A7%D7%95%D7%98%D7%99-Benthochromis-Tricoti
) [ {} \[\] out\_of\_stock ](  /items/4725261-%D7%98%D7%A8%D7%99%D7%A7%D7%95%D7%98%D7%99-Benthochromis-Tricoti
) 

[ צור קשר ](  /items/4725261-%D7%98%D7%A8%D7%99%D7%A7%D7%95%D7%98%D7%99-Benthochromis-Tricoti
) 

[ ![רגני-Julidochromis Regani](https://d3m9l0v76dty0.cloudfront.net/system/photos/9019823/original/226ce073cedc8676060e2b57d7877f50.png) ](  /items/4725344-%D7%A8%D7%92%D7%A0%D7%99-Julidochromis-Regani
)

[  רגני-Julidochromis Regani ](  /items/4725344-%D7%A8%D7%92%D7%A0%D7%99-Julidochromis-Regani
) [ {} \[\] out\_of\_stock ](  /items/4725344-%D7%A8%D7%92%D7%A0%D7%99-Julidochromis-Regani
) 

[ צור קשר ](  /items/4725344-%D7%A8%D7%92%D7%A0%D7%99-Julidochromis-Regani
) 

[ ![אוסקר-Oscar Cichlid](https://d3m9l0v76dty0.cloudfront.net/system/photos/10118675/original/ccfc7c95dc9ae313a4555b28618bdd6a.png) ](  /items/4737245-%D7%90%D7%95%D7%A1%D7%A7%D7%A8-Oscar-Cichlid
)

[  אוסקר-Oscar Cichlid ](  /items/4737245-%D7%90%D7%95%D7%A1%D7%A7%D7%A8-Oscar-Cichlid
) [ {} \[\] out\_of\_stock ](  /items/4737245-%D7%90%D7%95%D7%A1%D7%A7%D7%A8-Oscar-Cichlid
) 

[ צור קשר ](  /items/4737245-%D7%90%D7%95%D7%A1%D7%A7%D7%A8-Oscar-Cichlid
) 

[ ![זברה-Convict Cichlid](https://d3m9l0v76dty0.cloudfront.net/system/photos/10118687/original/801512ff9bbe521a9e7b78411630094f.png) ](  /items/4737250-%D7%96%D7%91%D7%A8%D7%94-Convict-Cichlid
)

[  זברה-Convict Cichlid ](  /items/4737250-%D7%96%D7%91%D7%A8%D7%94-Convict-Cichlid
) [ {} \[\] out\_of\_stock ](  /items/4737250-%D7%96%D7%91%D7%A8%D7%94-Convict-Cichlid
) 

[ צור קשר ](  /items/4737250-%D7%96%D7%91%D7%A8%D7%94-Convict-Cichlid
) 

[ ![קלבוס-Altolamprologus Calvus](https://d3m9l0v76dty0.cloudfront.net/system/photos/9019489/original/3038494dd07ee41b88c5091ebc71f9b7.png) ](  /items/4725225-%D7%A7%D7%9C%D7%91%D7%95%D7%A1-Altolamprologus-Calvus
)

[  קלבוס-Altolamprologus Calvus ](  /items/4725225-%D7%A7%D7%9C%D7%91%D7%95%D7%A1-Altolamprologus-Calvus
) [ {} \[\] out\_of\_stock ](  /items/4725225-%D7%A7%D7%9C%D7%91%D7%95%D7%A1-Altolamprologus-Calvus
) 

[ צור קשר ](  /items/4725225-%D7%A7%D7%9C%D7%91%D7%95%D7%A1-Altolamprologus-Calvus
) 

[ ![פיקוק או בי  - Peacock Cichlid Ob](https://d3m9l0v76dty0.cloudfront.net/system/photos/9015945/original/a72454074763d642c950e1862b15c8ea.png) ](  /items/4723947-%D7%A4%D7%99%D7%A7%D7%95%D7%A7-%D7%90%D7%95-%D7%91%D7%99-Peacock-Cichlid-Ob
)

[  פיקוק או בי - Peacock Cichlid Ob ](  /items/4723947-%D7%A4%D7%99%D7%A7%D7%95%D7%A7-%D7%90%D7%95-%D7%91%D7%99-Peacock-Cichlid-Ob
) [ {} \[\] out\_of\_stock ](  /items/4723947-%D7%A4%D7%99%D7%A7%D7%95%D7%A7-%D7%90%D7%95-%D7%91%D7%99-Peacock-Cichlid-Ob
) 

[ צור קשר ](  /items/4723947-%D7%A4%D7%99%D7%A7%D7%95%D7%A7-%D7%90%D7%95-%D7%91%D7%99-Peacock-Cichlid-Ob
) 

[ ![ציקליד פיקוק אדום(יוריקה)-Red Peacock Cichlid](https://d3m9l0v76dty0.cloudfront.net/system/photos/14037741/original/796300b4540de4df3c19ac56dadf9625.png) ](  /items/6682384-%D7%A6%D7%99%D7%A7%D7%9C%D7%99%D7%93-%D7%A4%D7%99%D7%A7%D7%95%D7%A7-%D7%90%D7%93%D7%95%D7%9D-%D7%99%D7%95%D7%A8%D7%99%D7%A7%D7%94-Red-Peacock-Cichlid
)

[  ציקליד פיקוק אדום(יוריקה)-Red Peacock Cichlid ](  /items/6682384-%D7%A6%D7%99%D7%A7%D7%9C%D7%99%D7%93-%D7%A4%D7%99%D7%A7%D7%95%D7%A7-%D7%90%D7%93%D7%95%D7%9D-%D7%99%D7%95%D7%A8%D7%99%D7%A7%D7%94-Red-Peacock-Cichlid
) [ {} \[\] out\_of\_stock ](  /items/6682384-%D7%A6%D7%99%D7%A7%D7%9C%D7%99%D7%93-%D7%A4%D7%99%D7%A7%D7%95%D7%A7-%D7%90%D7%93%D7%95%D7%9D-%D7%99%D7%95%D7%A8%D7%99%D7%A7%D7%94-Red-Peacock-Cichlid
) 

[ צור קשר ](  /items/6682384-%D7%A6%D7%99%D7%A7%D7%9C%D7%99%D7%93-%D7%A4%D7%99%D7%A7%D7%95%D7%A7-%D7%90%D7%93%D7%95%D7%9D-%D7%99%D7%95%D7%A8%D7%99%D7%A7%D7%94-Red-Peacock-Cichlid
) 

[ ![ציקליד קורליוס-Electric Yellow Cichlid](https://d3m9l0v76dty0.cloudfront.net/system/photos/14036490/original/d45ab3792a2825b9ed1c8ed5c2186c86.png) ](  /items/6681896-%D7%A6%D7%99%D7%A7%D7%9C%D7%99%D7%93-%D7%A7%D7%95%D7%A8%D7%9C%D7%99%D7%95%D7%A1-Electric-Yellow-Cichlid
)

[  ציקליד קורליוס-Electric Yellow Cichlid ](  /items/6681896-%D7%A6%D7%99%D7%A7%D7%9C%D7%99%D7%93-%D7%A7%D7%95%D7%A8%D7%9C%D7%99%D7%95%D7%A1-Electric-Yellow-Cichlid
) [ {} \[\] out\_of\_stock ](  /items/6681896-%D7%A6%D7%99%D7%A7%D7%9C%D7%99%D7%93-%D7%A7%D7%95%D7%A8%D7%9C%D7%99%D7%95%D7%A1-Electric-Yellow-Cichlid
) 

[ צור קשר ](  /items/6681896-%D7%A6%D7%99%D7%A7%D7%9C%D7%99%D7%93-%D7%A7%D7%95%D7%A8%D7%9C%D7%99%D7%95%D7%A1-Electric-Yellow-Cichlid
) 

[ ![חייל לוינסטוני -Venustus Cichlid ](https://d3m9l0v76dty0.cloudfront.net/system/photos/9018377/original/6bea0997664e5c76b270deb8d325c9b9.png) ](  /items/4724808-%D7%97%D7%99%D7%99%D7%9C-%D7%9C%D7%95%D7%99%D7%A0%D7%A1%D7%98%D7%95%D7%A0%D7%99-Venustus-Cichlid-
)

[  חייל לוינסטוני -Venustus Cichlid ](  /items/4724808-%D7%97%D7%99%D7%99%D7%9C-%D7%9C%D7%95%D7%99%D7%A0%D7%A1%D7%98%D7%95%D7%A0%D7%99-Venustus-Cichlid-
) [ {} \[\] out\_of\_stock ](  /items/4724808-%D7%97%D7%99%D7%99%D7%9C-%D7%9C%D7%95%D7%99%D7%A0%D7%A1%D7%98%D7%95%D7%A0%D7%99-Venustus-Cichlid-
) 

[ צור קשר ](  /items/4724808-%D7%97%D7%99%D7%99%D7%9C-%D7%9C%D7%95%D7%99%D7%A0%D7%A1%D7%98%D7%95%D7%A0%D7%99-Venustus-Cichlid-
) 

[ ![ציקליד דמסוני-Demasoni Cichlid](https://d3m9l0v76dty0.cloudfront.net/system/photos/14036560/original/975b3505bfb45ac9b9e18ceb7be2ca23.png) ](  /items/6681938-%D7%A6%D7%99%D7%A7%D7%9C%D7%99%D7%93-%D7%93%D7%9E%D7%A1%D7%95%D7%A0%D7%99-Demasoni-Cichlid
)

[  ציקליד דמסוני-Demasoni Cichlid ](  /items/6681938-%D7%A6%D7%99%D7%A7%D7%9C%D7%99%D7%93-%D7%93%D7%9E%D7%A1%D7%95%D7%A0%D7%99-Demasoni-Cichlid
) [ {} \[\] out\_of\_stock ](  /items/6681938-%D7%A6%D7%99%D7%A7%D7%9C%D7%99%D7%93-%D7%93%D7%9E%D7%A1%D7%95%D7%A0%D7%99-Demasoni-Cichlid
) 

[ צור קשר ](  /items/6681938-%D7%A6%D7%99%D7%A7%D7%9C%D7%99%D7%93-%D7%93%D7%9E%D7%A1%D7%95%D7%A0%D7%99-Demasoni-Cichlid
) 

[ ![מורי דולפין כחול-Blue Dolphin Cichlid](https://d3m9l0v76dty0.cloudfront.net/system/photos/9018616/original/8ab74fa75184b680d6186c85abd18aa4.png) ](  /items/4724870-%D7%9E%D7%95%D7%A8%D7%99-%D7%93%D7%95%D7%9C%D7%A4%D7%99%D7%9F-%D7%9B%D7%97%D7%95%D7%9C-Blue-Dolphin-Cichlid
)

[  מורי דולפין כחול-Blue Dolphin Cichlid ](  /items/4724870-%D7%9E%D7%95%D7%A8%D7%99-%D7%93%D7%95%D7%9C%D7%A4%D7%99%D7%9F-%D7%9B%D7%97%D7%95%D7%9C-Blue-Dolphin-Cichlid
) [ {} \[\] out\_of\_stock ](  /items/4724870-%D7%9E%D7%95%D7%A8%D7%99-%D7%93%D7%95%D7%9C%D7%A4%D7%99%D7%9F-%D7%9B%D7%97%D7%95%D7%9C-Blue-Dolphin-Cichlid
) 

[ צור קשר ](  /items/4724870-%D7%9E%D7%95%D7%A8%D7%99-%D7%93%D7%95%D7%9C%D7%A4%D7%99%D7%9F-%D7%9B%D7%97%D7%95%D7%9C-Blue-Dolphin-Cichlid
) 

[ ![ציקליד מנגנו-Maingano Cichlid](https://d3m9l0v76dty0.cloudfront.net/system/photos/14037579/original/bcbbd4f34b7ac082c557bd6724ef56b2.png) ](  /items/6682322-%D7%A6%D7%99%D7%A7%D7%9C%D7%99%D7%93-%D7%9E%D7%A0%D7%92%D7%A0%D7%95-Maingano-Cichlid
)

[  ציקליד מנגנו-Maingano Cichlid ](  /items/6682322-%D7%A6%D7%99%D7%A7%D7%9C%D7%99%D7%93-%D7%9E%D7%A0%D7%92%D7%A0%D7%95-Maingano-Cichlid
) [ {} \[\] out\_of\_stock ](  /items/6682322-%D7%A6%D7%99%D7%A7%D7%9C%D7%99%D7%93-%D7%9E%D7%A0%D7%92%D7%A0%D7%95-Maingano-Cichlid
) 

[ צור קשר ](  /items/6682322-%D7%A6%D7%99%D7%A7%D7%9C%D7%99%D7%93-%D7%9E%D7%A0%D7%92%D7%A0%D7%95-Maingano-Cichlid
) 

הקודם 1 [2](/248692-%D7%90%D7%99%D7%A0%D7%93%D7%A7%D7%A1-%D7%93%D7%92%D7%99-%D7%A0%D7%95%D7%99-?page=2) [3](/248692-%D7%90%D7%99%D7%A0%D7%93%D7%A7%D7%A1-%D7%93%D7%92%D7%99-%D7%A0%D7%95%D7%99-?page=3) [4](/248692-%D7%90%D7%99%D7%A0%D7%93%D7%A7%D7%A1-%D7%93%D7%92%D7%99-%D7%A0%D7%95%D7%99-?page=4) [5](/248692-%D7%90%D7%99%D7%A0%D7%93%D7%A7%D7%A1-%D7%93%D7%92%D7%99-%D7%A0%D7%95%D7%99-?page=5) [6](/248692-%D7%90%D7%99%D7%A0%D7%93%D7%A7%D7%A1-%D7%93%D7%92%D7%99-%D7%A0%D7%95%D7%99-?page=6) [7](/248692-%D7%90%D7%99%D7%A0%D7%93%D7%A7%D7%A1-%D7%93%D7%92%D7%99-%D7%A0%D7%95%D7%99-?page=7) [8](/248692-%D7%90%D7%99%D7%A0%D7%93%D7%A7%D7%A1-%D7%93%D7%92%D7%99-%D7%A0%D7%95%D7%99-?page=8) [9](/248692-%D7%90%D7%99%D7%A0%D7%93%D7%A7%D7%A1-%D7%93%D7%92%D7%99-%D7%A0%D7%95%D7%99-?page=9) … [20](/248692-%D7%90%D7%99%D7%A0%D7%93%D7%A7%D7%A1-%D7%93%D7%92%D7%99-%D7%A0%D7%95%D7%99-?page=20) [21](/248692-%D7%90%D7%99%D7%A0%D7%93%D7%A7%D7%A1-%D7%93%D7%92%D7%99-%D7%A0%D7%95%D7%99-?page=21) [הבא](/248692-%D7%90%D7%99%D7%A0%D7%93%D7%A7%D7%A1-%D7%93%D7%92%D7%99-%D7%A0%D7%95%D7%99-?page=2)

### הרשמו למועדון ותהנו מהטבות!

שם 

טלפון 

מייל 

ריק 

צרפו אותי 

מעוניין לקבל מבצעים בדוא"ל 

### מפת אתר

* [אודות](https://www.perfectreef.co.il/about)
* [צור קשר](https://www.perfectreef.co.il/contact)
* [הגעה](https://www.perfectreef.co.il/location)
* [תקנון החנות](https://www.perfectreef.co.il/contract)
* [מעקב הזמנות](https://www.perfectreef.co.il/customer%5Flogin)
* [הרשמת לקוחות](https://www.perfectreef.co.il/customer%5Fsignup)
* [ מידע נוסף ](https://www.perfectreef.co.il/pages/44119-עוד-מידע)
* [ מדיניות משלוחים ](https://www.perfectreef.co.il/pages/47569-delivery)
* [ הצהרת נגישות ](https://www.perfectreef.co.il/pages/49966-%D7%94%D7%A6%D7%94%D7%A8%D7%AA-%D7%A0%D7%92%D7%99%D7%A9%D7%95%D7%AA)

### קטגוריות

* [דגים](https://www.perfectreef.co.il/246269-%D7%93%D7%92%D7%99%D7%9D)  
   * [אקווריומים ](https://www.perfectreef.co.il/246272-%D7%90%D7%A7%D7%95%D7%95%D7%A8%D7%99%D7%95%D7%9E%D7%99%D7%9D-)  
   * [משאבות מים](https://www.perfectreef.co.il/248063-%D7%9E%D7%A9%D7%90%D7%91%D7%95%D7%AA-%D7%9E%D7%99%D7%9D)  
   * [משאבות אוויר וציודן](https://www.perfectreef.co.il/248064-%D7%9E%D7%A9%D7%90%D7%91%D7%95%D7%AA-%D7%90%D7%95%D7%95%D7%99%D7%A8-%D7%95%D7%A6%D7%99%D7%95%D7%93%D7%9F)  
   * [משאבות גלים](https://www.perfectreef.co.il/248067-%D7%9E%D7%A9%D7%90%D7%91%D7%95%D7%AA-%D7%92%D7%9C%D7%99%D7%9D)  
   * [מדיות וסופחים ](https://www.perfectreef.co.il/246317-%D7%9E%D7%93%D7%99%D7%95%D7%AA-%D7%95%D7%A1%D7%95%D7%A4%D7%97%D7%99%D7%9D-)  
   * [תכשירים ותוספים לאקווריום](https://www.perfectreef.co.il/247103-%D7%AA%D7%9B%D7%A9%D7%99%D7%A8%D7%99%D7%9D-%D7%95%D7%AA%D7%95%D7%A1%D7%A4%D7%99%D7%9D-%D7%9C%D7%90%D7%A7%D7%95%D7%95%D7%A8%D7%99%D7%95%D7%9D)  
   * [תרופות דגים/אלמוגים](https://www.perfectreef.co.il/249826-%D7%AA%D7%A8%D7%95%D7%A4%D7%95%D7%AA-%D7%93%D7%92%D7%99%D7%9D-%D7%90%D7%9C%D7%9E%D7%95%D7%92%D7%99%D7%9D)  
   * [מגנטים, סקרפרים וציוד ניקוי](https://www.perfectreef.co.il/248058-%D7%9E%D7%92%D7%A0%D7%98%D7%99%D7%9D-%D7%A1%D7%A7%D7%A8%D7%A4%D7%A8%D7%99%D7%9D-%D7%95%D7%A6%D7%99%D7%95%D7%93-%D7%A0%D7%99%D7%A7%D7%95%D7%99)  
   * [גופי חימום ומדי חום](https://www.perfectreef.co.il/248065-%D7%92%D7%95%D7%A4%D7%99-%D7%97%D7%99%D7%9E%D7%95%D7%9D-%D7%95%D7%9E%D7%93%D7%99-%D7%97%D7%95%D7%9D)  
   * [מקררים ומאווררי קירור](https://www.perfectreef.co.il/248066-%D7%9E%D7%A7%D7%A8%D7%A8%D7%99%D7%9D-%D7%95%D7%9E%D7%90%D7%95%D7%95%D7%A8%D7%A8%D7%99-%D7%A7%D7%99%D7%A8%D7%95%D7%A8)  
   * [ערכות בדיקה](https://www.perfectreef.co.il/246276-%D7%A2%D7%A8%D7%9B%D7%95%D7%AA-%D7%91%D7%93%D7%99%D7%A7%D7%94)  
   * [ציוד נלווה](https://www.perfectreef.co.il/246332-%D7%A6%D7%99%D7%95%D7%93-%D7%A0%D7%9C%D7%95%D7%95%D7%94)  
   * [חומרי סינון לאקווריום](https://www.perfectreef.co.il/264646-%D7%97%D7%95%D7%9E%D7%A8%D7%99-%D7%A1%D7%99%D7%A0%D7%95%D7%9F-%D7%9C%D7%90%D7%A7%D7%95%D7%95%D7%A8%D7%99%D7%95%D7%9D)  
   * [מערכות UV ואוזון](https://www.perfectreef.co.il/248070-%D7%9E%D7%A2%D7%A8%D7%9B%D7%95%D7%AA-UV-%D7%95%D7%90%D7%95%D7%96%D7%95%D7%9F)  
   * [דקורציות](https://www.perfectreef.co.il/248069-%D7%93%D7%A7%D7%95%D7%A8%D7%A6%D7%99%D7%95%D7%AA)  
   * [גופי תאורה](https://www.perfectreef.co.il/248394-%D7%92%D7%95%D7%A4%D7%99-%D7%AA%D7%90%D7%95%D7%A8%D7%94)  
   * [סיליקון ודבקים לאקווריום](https://www.perfectreef.co.il/248398-%D7%A1%D7%99%D7%9C%D7%99%D7%A7%D7%95%D7%9F-%D7%95%D7%93%D7%91%D7%A7%D7%99%D7%9D-%D7%9C%D7%90%D7%A7%D7%95%D7%95%D7%A8%D7%99%D7%95%D7%9D)  
   * [מצעים וחצצים](https://www.perfectreef.co.il/248811-%D7%9E%D7%A6%D7%A2%D7%99%D7%9D-%D7%95%D7%97%D7%A6%D7%A6%D7%99%D7%9D)  
   * [מערכות אוסמוזה וציודן](https://www.perfectreef.co.il/248820-%D7%9E%D7%A2%D7%A8%D7%9B%D7%95%D7%AA-%D7%90%D7%95%D7%A1%D7%9E%D7%95%D7%96%D7%94-%D7%95%D7%A6%D7%99%D7%95%D7%93%D7%9F)  
   * [מאכילים אוטומטיים](https://www.perfectreef.co.il/248821-%D7%9E%D7%90%D7%9B%D7%99%D7%9C%D7%99%D7%9D-%D7%90%D7%95%D7%98%D7%95%D7%9E%D7%98%D7%99%D7%99%D7%9D)  
   * [צינורות גמישים ומחברים](https://www.perfectreef.co.il/248823-%D7%A6%D7%99%D7%A0%D7%95%D7%A8%D7%95%D7%AA-%D7%92%D7%9E%D7%99%D7%A9%D7%99%D7%9D-%D7%95%D7%9E%D7%97%D7%91%D7%A8%D7%99%D7%9D)  
   * [משאבות מינון](https://www.perfectreef.co.il/295372-%D7%9E%D7%A9%D7%90%D7%91%D7%95%D7%AA-%D7%9E%D7%99%D7%A0%D7%95%D7%9F)  
   * [שואבי רפש](https://www.perfectreef.co.il/248068-%D7%A9%D7%95%D7%90%D7%91%D7%99-%D7%A8%D7%A4%D7%A9)  
   * [תאי השרצה, אקלום ומלכודות ](https://www.perfectreef.co.il/354094-%D7%AA%D7%90%D7%99-%D7%94%D7%A9%D7%A8%D7%A6%D7%94-%D7%90%D7%A7%D7%9C%D7%95%D7%9D-%D7%95%D7%9E%D7%9C%D7%9B%D7%95%D7%93%D7%95%D7%AA-)  
   * [מערכות פיצוי אידוי ](https://www.perfectreef.co.il/252927-%D7%9E%D7%A2%D7%A8%D7%9B%D7%95%D7%AA-%D7%A4%D7%99%D7%A6%D7%95%D7%99-%D7%90%D7%99%D7%93%D7%95%D7%99-)  
   * [חלקי צנרת PVC](https://www.perfectreef.co.il/248396-%D7%97%D7%9C%D7%A7%D7%99-%D7%A6%D7%A0%D7%A8%D7%AA-PVC)  
   * מחלקת מים מלוחים  
   * [פורקי חלבונים וקולונות](https://www.perfectreef.co.il/246295-%D7%A4%D7%95%D7%A8%D7%A7%D7%99-%D7%97%D7%9C%D7%91%D7%95%D7%A0%D7%99%D7%9D-%D7%95%D7%A7%D7%95%D7%9C%D7%95%D7%A0%D7%95%D7%AA)  
   * [מזונות לדגי ים ](https://www.perfectreef.co.il/247100-%D7%9E%D7%96%D7%95%D7%A0%D7%95%D7%AA-%D7%9C%D7%93%D7%92%D7%99-%D7%99%D7%9D-)  
   * [תכשירים ותוספים למלוחים](https://www.perfectreef.co.il/246268-%D7%AA%D7%9B%D7%A9%D7%99%D7%A8%D7%99%D7%9D-%D7%95%D7%AA%D7%95%D7%A1%D7%A4%D7%99%D7%9D-%D7%9C%D7%9E%D7%9C%D7%95%D7%97%D7%99%D7%9D)  
   * [מזונות אלמוגים וחסרי חוליות](https://www.perfectreef.co.il/734248-%D7%9E%D7%96%D7%95%D7%A0%D7%95%D7%AA-%D7%90%D7%9C%D7%9E%D7%95%D7%92%D7%99%D7%9D-%D7%95%D7%97%D7%A1%D7%A8%D7%99-%D7%97%D7%95%D7%9C%D7%99%D7%95%D7%AA)  
   * [מלחים ](https://www.perfectreef.co.il/265540-%D7%9E%D7%9C%D7%97%D7%99%D7%9D-)  
   * [מדי מליחות ועזרים למלוחים](https://www.perfectreef.co.il/248059-%D7%9E%D7%93%D7%99-%D7%9E%D7%9C%D7%99%D7%97%D7%95%D7%AA-%D7%95%D7%A2%D7%96%D7%A8%D7%99%D7%9D-%D7%9C%D7%9E%D7%9C%D7%95%D7%97%D7%99%D7%9D)  
   * [סופחים למלוחים](https://www.perfectreef.co.il/265379-%D7%A1%D7%95%D7%A4%D7%97%D7%99%D7%9D-%D7%9C%D7%9E%D7%9C%D7%95%D7%97%D7%99%D7%9D)  
   * מחלקת מים מתוקים  
   * [פילטרים פנימיים](https://www.perfectreef.co.il/247102-%D7%A4%D7%99%D7%9C%D7%98%D7%A8%D7%99%D7%9D-%D7%A4%D7%A0%D7%99%D7%9E%D7%99%D7%99%D7%9D)  
   * [פילטרים חיצוניים](https://www.perfectreef.co.il/248060-%D7%A4%D7%99%D7%9C%D7%98%D7%A8%D7%99%D7%9D-%D7%97%D7%99%D7%A6%D7%95%D7%A0%D7%99%D7%99%D7%9D)  
   * [מזונות דגים וחסרי חוליות](https://www.perfectreef.co.il/246280-%D7%9E%D7%96%D7%95%D7%A0%D7%95%D7%AA-%D7%93%D7%92%D7%99%D7%9D-%D7%95%D7%97%D7%A1%D7%A8%D7%99-%D7%97%D7%95%D7%9C%D7%99%D7%95%D7%AA)  
   * [תכשירים ותוספים לאקווריום צמחיה ](https://www.perfectreef.co.il/246296-%D7%AA%D7%9B%D7%A9%D7%99%D7%A8%D7%99%D7%9D-%D7%95%D7%AA%D7%95%D7%A1%D7%A4%D7%99%D7%9D-%D7%9C%D7%90%D7%A7%D7%95%D7%95%D7%A8%D7%99%D7%95%D7%9D-%D7%A6%D7%9E%D7%97%D7%99%D7%94-)  
   * [ציוד לאקווריום צמחיה](https://www.perfectreef.co.il/257470-%D7%A6%D7%99%D7%95%D7%93-%D7%9C%D7%90%D7%A7%D7%95%D7%95%D7%A8%D7%99%D7%95%D7%9D-%D7%A6%D7%9E%D7%97%D7%99%D7%94)  
   * [ספוגים וחלקי חילוף לפילטרים](https://www.perfectreef.co.il/257284-%D7%A1%D7%A4%D7%95%D7%92%D7%99%D7%9D-%D7%95%D7%97%D7%9C%D7%A7%D7%99-%D7%97%D7%99%D7%9C%D7%95%D7%A3-%D7%9C%D7%A4%D7%99%D7%9C%D7%98%D7%A8%D7%99%D7%9D)  
   * [חלקי חילוף לג'אוול](https://www.perfectreef.co.il/248062-%D7%97%D7%9C%D7%A7%D7%99-%D7%97%D7%99%D7%9C%D7%95%D7%A3-%D7%9C%D7%92-%D7%90%D7%95%D7%95%D7%9C)  
   * מחלקת בריכות נוי  
   * [משאבות מים לבריכות](https://www.perfectreef.co.il/248072-%D7%9E%D7%A9%D7%90%D7%91%D7%95%D7%AA-%D7%9E%D7%99%D7%9D-%D7%9C%D7%91%D7%A8%D7%99%D7%9B%D7%95%D7%AA)  
   * [בריכות נוי וציודם ](https://www.perfectreef.co.il/246300-%D7%91%D7%A8%D7%99%D7%9B%D7%95%D7%AA-%D7%A0%D7%95%D7%99-%D7%95%D7%A6%D7%99%D7%95%D7%93%D7%9D-)  
   * [פילטרים לבריכות](https://www.perfectreef.co.il/248071-%D7%A4%D7%99%D7%9C%D7%98%D7%A8%D7%99%D7%9D-%D7%9C%D7%91%D7%A8%D7%99%D7%9B%D7%95%D7%AA)  
   * [תאורות לבריכות](https://www.perfectreef.co.il/248073-%D7%AA%D7%90%D7%95%D7%A8%D7%95%D7%AA-%D7%9C%D7%91%D7%A8%D7%99%D7%9B%D7%95%D7%AA)  
   * [תכשירים ותוספים לבריכות](https://www.perfectreef.co.il/252104-%D7%AA%D7%9B%D7%A9%D7%99%D7%A8%D7%99%D7%9D-%D7%95%D7%AA%D7%95%D7%A1%D7%A4%D7%99%D7%9D-%D7%9C%D7%91%D7%A8%D7%99%D7%9B%D7%95%D7%AA)  
   * [מזונות דגי בריכה](https://www.perfectreef.co.il/254849-%D7%9E%D7%96%D7%95%D7%A0%D7%95%D7%AA-%D7%93%D7%92%D7%99-%D7%91%D7%A8%D7%99%D7%9B%D7%94)
* [כלבים](https://www.perfectreef.co.il/246271-%D7%9B%D7%9C%D7%91%D7%99%D7%9D)  
   * [מזון יבש כלבים ](https://www.perfectreef.co.il/246279-%D7%9E%D7%96%D7%95%D7%9F-%D7%99%D7%91%D7%A9-%D7%9B%D7%9C%D7%91%D7%99%D7%9D-)  
   * [מזון רפואי כלבים](https://www.perfectreef.co.il/246333-%D7%9E%D7%96%D7%95%D7%9F-%D7%A8%D7%A4%D7%95%D7%90%D7%99-%D7%9B%D7%9C%D7%91%D7%99%D7%9D)  
   * [עצמות דחוסות וקשר כלבים](https://www.perfectreef.co.il/246299-%D7%A2%D7%A6%D7%9E%D7%95%D7%AA-%D7%93%D7%97%D7%95%D7%A1%D7%95%D7%AA-%D7%95%D7%A7%D7%A9%D7%A8-%D7%9B%D7%9C%D7%91%D7%99%D7%9D)  
   * [חטיפי כלבים ](https://www.perfectreef.co.il/246286-%D7%97%D7%98%D7%99%D7%A4%D7%99-%D7%9B%D7%9C%D7%91%D7%99%D7%9D-)  
   * [שימורים ומעדני כלבים](https://www.perfectreef.co.il/246273-%D7%A9%D7%99%D7%9E%D7%95%D7%A8%D7%99%D7%9D-%D7%95%D7%9E%D7%A2%D7%93%D7%A0%D7%99-%D7%9B%D7%9C%D7%91%D7%99%D7%9D)  
   * [תוספי תזונה כלבים](https://www.perfectreef.co.il/246310-%D7%AA%D7%95%D7%A1%D7%A4%D7%99-%D7%AA%D7%96%D7%95%D7%A0%D7%94-%D7%9B%D7%9C%D7%91%D7%99%D7%9D)  
   * [צעצועי כלבים](https://www.perfectreef.co.il/246334-%D7%A6%D7%A2%D7%A6%D7%95%D7%A2%D7%99-%D7%9B%D7%9C%D7%91%D7%99%D7%9D)  
   * [כלי אוכל ושתיה כלבים](https://www.perfectreef.co.il/246298-%D7%9B%D7%9C%D7%99-%D7%90%D7%95%D7%9B%D7%9C-%D7%95%D7%A9%D7%AA%D7%99%D7%94-%D7%9B%D7%9C%D7%91%D7%99%D7%9D)  
   * [מוצרי טיפוח לכלבים](https://www.perfectreef.co.il/246284-%D7%9E%D7%95%D7%A6%D7%A8%D7%99-%D7%98%D7%99%D7%A4%D7%95%D7%97-%D7%9C%D7%9B%D7%9C%D7%91%D7%99%D7%9D)  
   * [מוצרי היגיינה לכלבים](https://www.perfectreef.co.il/272962-%D7%9E%D7%95%D7%A6%D7%A8%D7%99-%D7%94%D7%99%D7%92%D7%99%D7%99%D7%A0%D7%94-%D7%9C%D7%9B%D7%9C%D7%91%D7%99%D7%9D)  
   * [מיטות ומזרני כלבים](https://www.perfectreef.co.il/246293-%D7%9E%D7%99%D7%98%D7%95%D7%AA-%D7%95%D7%9E%D7%96%D7%A8%D7%A0%D7%99-%D7%9B%D7%9C%D7%91%D7%99%D7%9D)  
   * [קולרים ורצועות כלבים](https://www.perfectreef.co.il/246283-%D7%A7%D7%95%D7%9C%D7%A8%D7%99%D7%9D-%D7%95%D7%A8%D7%A6%D7%95%D7%A2%D7%95%D7%AA-%D7%9B%D7%9C%D7%91%D7%99%D7%9D)  
   * [כלובי נשיאה ותיקי כלבים](https://www.perfectreef.co.il/246270-%D7%9B%D7%9C%D7%95%D7%91%D7%99-%D7%A0%D7%A9%D7%99%D7%90%D7%94-%D7%95%D7%AA%D7%99%D7%A7%D7%99-%D7%9B%D7%9C%D7%91%D7%99%D7%9D)  
   * [ציוד ותכשירי אילוף ומשמעת כלבים](https://www.perfectreef.co.il/246312-%D7%A6%D7%99%D7%95%D7%93-%D7%95%D7%AA%D7%9B%D7%A9%D7%99%D7%A8%D7%99-%D7%90%D7%99%D7%9C%D7%95%D7%A3-%D7%95%D7%9E%D7%A9%D7%9E%D7%A2%D7%AA-%D7%9B%D7%9C%D7%91%D7%99%D7%9D)  
   * [כלובים וגדרות אילוף כלבים](https://www.perfectreef.co.il/246337-%D7%9B%D7%9C%D7%95%D7%91%D7%99%D7%9D-%D7%95%D7%92%D7%93%D7%A8%D7%95%D7%AA-%D7%90%D7%99%D7%9C%D7%95%D7%A3-%D7%9B%D7%9C%D7%91%D7%99%D7%9D)  
   * [מרחיקי כלבים ](https://www.perfectreef.co.il/246314-%D7%9E%D7%A8%D7%97%D7%99%D7%A7%D7%99-%D7%9B%D7%9C%D7%91%D7%99%D7%9D-)  
   * [מוצרי הדברה כלבים](https://www.perfectreef.co.il/246285-%D7%9E%D7%95%D7%A6%D7%A8%D7%99-%D7%94%D7%93%D7%91%D7%A8%D7%94-%D7%9B%D7%9C%D7%91%D7%99%D7%9D)  
   * [מזרקות מים לשתיה כלבים](https://www.perfectreef.co.il/262982-%D7%9E%D7%96%D7%A8%D7%A7%D7%95%D7%AA-%D7%9E%D7%99%D7%9D-%D7%9C%D7%A9%D7%AA%D7%99%D7%94-%D7%9B%D7%9C%D7%91%D7%99%D7%9D)
* [חתולים](https://www.perfectreef.co.il/246275-%D7%97%D7%AA%D7%95%D7%9C%D7%99%D7%9D)  
   * [מזון יבש חתולים](https://www.perfectreef.co.il/246278-%D7%9E%D7%96%D7%95%D7%9F-%D7%99%D7%91%D7%A9-%D7%97%D7%AA%D7%95%D7%9C%D7%99%D7%9D)  
   * [שימורים ומעדני חתולים](https://www.perfectreef.co.il/248504-%D7%A9%D7%99%D7%9E%D7%95%D7%A8%D7%99%D7%9D-%D7%95%D7%9E%D7%A2%D7%93%D7%A0%D7%99-%D7%97%D7%AA%D7%95%D7%9C%D7%99%D7%9D)  
   * [מוצרי הדברה לחתולים](https://www.perfectreef.co.il/256442-%D7%9E%D7%95%D7%A6%D7%A8%D7%99-%D7%94%D7%93%D7%91%D7%A8%D7%94-%D7%9C%D7%97%D7%AA%D7%95%D7%9C%D7%99%D7%9D)  
   * [חול חתולים ](https://www.perfectreef.co.il/246294-%D7%97%D7%95%D7%9C-%D7%97%D7%AA%D7%95%D7%9C%D7%99%D7%9D-)  
   * [שירותי חתולים](https://www.perfectreef.co.il/246307-%D7%A9%D7%99%D7%A8%D7%95%D7%AA%D7%99-%D7%97%D7%AA%D7%95%D7%9C%D7%99%D7%9D)  
   * [מגרדות חתולים](https://www.perfectreef.co.il/246289-%D7%9E%D7%92%D7%A8%D7%93%D7%95%D7%AA-%D7%97%D7%AA%D7%95%D7%9C%D7%99%D7%9D)  
   * [חטיפי חתולים](https://www.perfectreef.co.il/246321-%D7%97%D7%98%D7%99%D7%A4%D7%99-%D7%97%D7%AA%D7%95%D7%9C%D7%99%D7%9D)  
   * [תוספי חתולים](https://www.perfectreef.co.il/248179-%D7%AA%D7%95%D7%A1%D7%A4%D7%99-%D7%97%D7%AA%D7%95%D7%9C%D7%99%D7%9D)  
   * [מוצרי היגיינה וטיפוח חתולים](https://www.perfectreef.co.il/248229-%D7%9E%D7%95%D7%A6%D7%A8%D7%99-%D7%94%D7%99%D7%92%D7%99%D7%99%D7%A0%D7%94-%D7%95%D7%98%D7%99%D7%A4%D7%95%D7%97-%D7%97%D7%AA%D7%95%D7%9C%D7%99%D7%9D)  
   * [קולרי חתולים](https://www.perfectreef.co.il/246325-%D7%A7%D7%95%D7%9C%D7%A8%D7%99-%D7%97%D7%AA%D7%95%D7%9C%D7%99%D7%9D)  
   * [צעצועי חתולים](https://www.perfectreef.co.il/246303-%D7%A6%D7%A2%D7%A6%D7%95%D7%A2%D7%99-%D7%97%D7%AA%D7%95%D7%9C%D7%99%D7%9D)  
   * [מנשאות וכלובי חתולים](https://www.perfectreef.co.il/246297-%D7%9E%D7%A0%D7%A9%D7%90%D7%95%D7%AA-%D7%95%D7%9B%D7%9C%D7%95%D7%91%D7%99-%D7%97%D7%AA%D7%95%D7%9C%D7%99%D7%9D)  
   * [כלי אוכל ושתיה חתולים](https://www.perfectreef.co.il/246274-%D7%9B%D7%9C%D7%99-%D7%90%D7%95%D7%9B%D7%9C-%D7%95%D7%A9%D7%AA%D7%99%D7%94-%D7%97%D7%AA%D7%95%D7%9C%D7%99%D7%9D)  
   * [מרחיקי חתולים ](https://www.perfectreef.co.il/246326-%D7%9E%D7%A8%D7%97%D7%99%D7%A7%D7%99-%D7%97%D7%AA%D7%95%D7%9C%D7%99%D7%9D-)  
   * [מיטות ומזרני חתולים](https://www.perfectreef.co.il/246328-%D7%9E%D7%99%D7%98%D7%95%D7%AA-%D7%95%D7%9E%D7%96%D7%A8%D7%A0%D7%99-%D7%97%D7%AA%D7%95%D7%9C%D7%99%D7%9D)  
   * [מזון רפואי חתולים ](https://www.perfectreef.co.il/246327-%D7%9E%D7%96%D7%95%D7%9F-%D7%A8%D7%A4%D7%95%D7%90%D7%99-%D7%97%D7%AA%D7%95%D7%9C%D7%99%D7%9D-)  
   * [מזרקות מים לשתיה לחתולים](https://www.perfectreef.co.il/262932-%D7%9E%D7%96%D7%A8%D7%A7%D7%95%D7%AA-%D7%9E%D7%99%D7%9D-%D7%9C%D7%A9%D7%AA%D7%99%D7%94-%D7%9C%D7%97%D7%AA%D7%95%D7%9C%D7%99%D7%9D)
* [ציפורים ](https://www.perfectreef.co.il/246282-%D7%A6%D7%99%D7%A4%D7%95%D7%A8%D7%99%D7%9D-)  
   * [כלובי ציפורים](https://www.perfectreef.co.il/248235-%D7%9B%D7%9C%D7%95%D7%91%D7%99-%D7%A6%D7%99%D7%A4%D7%95%D7%A8%D7%99%D7%9D)  
   * [מזון ציפורים](https://www.perfectreef.co.il/246292-%D7%9E%D7%96%D7%95%D7%9F-%D7%A6%D7%99%D7%A4%D7%95%D7%A8%D7%99%D7%9D)  
   * [ חטיפי ציפורים](https://www.perfectreef.co.il/248164--%D7%97%D7%98%D7%99%D7%A4%D7%99-%D7%A6%D7%99%D7%A4%D7%95%D7%A8%D7%99%D7%9D)  
   * [תוספי ציפורים](https://www.perfectreef.co.il/246323-%D7%AA%D7%95%D7%A1%D7%A4%D7%99-%D7%A6%D7%99%D7%A4%D7%95%D7%A8%D7%99%D7%9D)  
   * [צעצועים ואביזרי ציפורים](https://www.perfectreef.co.il/246281-%D7%A6%D7%A2%D7%A6%D7%95%D7%A2%D7%99%D7%9D-%D7%95%D7%90%D7%91%D7%99%D7%96%D7%A8%D7%99-%D7%A6%D7%99%D7%A4%D7%95%D7%A8%D7%99%D7%9D)
* [מכרסמים ](https://www.perfectreef.co.il/246288-%D7%9E%D7%9B%D7%A8%D7%A1%D7%9E%D7%99%D7%9D-)  
   * [כלובי מכרסמים](https://www.perfectreef.co.il/246291-%D7%9B%D7%9C%D7%95%D7%91%D7%99-%D7%9E%D7%9B%D7%A8%D7%A1%D7%9E%D7%99%D7%9D)  
   * [חטיפים ותוספים מכרסמים](https://www.perfectreef.co.il/246287-%D7%97%D7%98%D7%99%D7%A4%D7%99%D7%9D-%D7%95%D7%AA%D7%95%D7%A1%D7%A4%D7%99%D7%9D-%D7%9E%D7%9B%D7%A8%D7%A1%D7%9E%D7%99%D7%9D)  
   * [בתי מחסה למכרסמים](https://www.perfectreef.co.il/348540-%D7%91%D7%AA%D7%99-%D7%9E%D7%97%D7%A1%D7%94-%D7%9C%D7%9E%D7%9B%D7%A8%D7%A1%D7%9E%D7%99%D7%9D)  
   * [כלי אוכל ושתיה למכרסמים](https://www.perfectreef.co.il/349107-%D7%9B%D7%9C%D7%99-%D7%90%D7%95%D7%9B%D7%9C-%D7%95%D7%A9%D7%AA%D7%99%D7%94-%D7%9C%D7%9E%D7%9B%D7%A8%D7%A1%D7%9E%D7%99%D7%9D)  
   * [מזון מכרסמים](https://www.perfectreef.co.il/248168-%D7%9E%D7%96%D7%95%D7%9F-%D7%9E%D7%9B%D7%A8%D7%A1%D7%9E%D7%99%D7%9D)  
   * [מצע מכרסמים ](https://www.perfectreef.co.il/246308-%D7%9E%D7%A6%D7%A2-%D7%9E%D7%9B%D7%A8%D7%A1%D7%9E%D7%99%D7%9D-)  
   * [צעצועי מכרסמים](https://www.perfectreef.co.il/246324-%D7%A6%D7%A2%D7%A6%D7%95%D7%A2%D7%99-%D7%9E%D7%9B%D7%A8%D7%A1%D7%9E%D7%99%D7%9D)  
   * [מוצרי היגיינה וטיפוח מכרסמים](https://www.perfectreef.co.il/248230-%D7%9E%D7%95%D7%A6%D7%A8%D7%99-%D7%94%D7%99%D7%92%D7%99%D7%99%D7%A0%D7%94-%D7%95%D7%98%D7%99%D7%A4%D7%95%D7%97-%D7%9E%D7%9B%D7%A8%D7%A1%D7%9E%D7%99%D7%9D)
* [זוחלים ](https://www.perfectreef.co.il/246306-%D7%96%D7%95%D7%97%D7%9C%D7%99%D7%9D-)  
   * [טרריומים ופולידריומים](https://www.perfectreef.co.il/246305-%D7%98%D7%A8%D7%A8%D7%99%D7%95%D7%9E%D7%99%D7%9D-%D7%95%D7%A4%D7%95%D7%9C%D7%99%D7%93%D7%A8%D7%99%D7%95%D7%9E%D7%99%D7%9D)  
   * [מצע זוחלים](https://www.perfectreef.co.il/246329-%D7%9E%D7%A6%D7%A2-%D7%96%D7%95%D7%97%D7%9C%D7%99%D7%9D)  
   * [שטיחים אקולוגיים](https://www.perfectreef.co.il/261752-%D7%A9%D7%98%D7%99%D7%97%D7%99%D7%9D-%D7%90%D7%A7%D7%95%D7%9C%D7%95%D7%92%D7%99%D7%99%D7%9D)  
   * [תאורת זוחלים](https://www.perfectreef.co.il/246313-%D7%AA%D7%90%D7%95%D7%A8%D7%AA-%D7%96%D7%95%D7%97%D7%9C%D7%99%D7%9D)  
   * [כלי האכלה זוחלים](https://www.perfectreef.co.il/248097-%D7%9B%D7%9C%D7%99-%D7%94%D7%90%D7%9B%D7%9C%D7%94-%D7%96%D7%95%D7%97%D7%9C%D7%99%D7%9D)  
   * [דקורציות ומחסה לזוחלים](https://www.perfectreef.co.il/246335-%D7%93%D7%A7%D7%95%D7%A8%D7%A6%D7%99%D7%95%D7%AA-%D7%95%D7%9E%D7%97%D7%A1%D7%94-%D7%9C%D7%96%D7%95%D7%97%D7%9C%D7%99%D7%9D)  
   * [מוצרי חימום זוחלים](https://www.perfectreef.co.il/246336-%D7%9E%D7%95%D7%A6%D7%A8%D7%99-%D7%97%D7%99%D7%9E%D7%95%D7%9D-%D7%96%D7%95%D7%97%D7%9C%D7%99%D7%9D)  
   * [אבני חימום לזוחלים](https://www.perfectreef.co.il/257998-%D7%90%D7%91%D7%A0%D7%99-%D7%97%D7%99%D7%9E%D7%95%D7%9D-%D7%9C%D7%96%D7%95%D7%97%D7%9C%D7%99%D7%9D)  
   * [ציוד זוחלים ](https://www.perfectreef.co.il/246331-%D7%A6%D7%99%D7%95%D7%93-%D7%96%D7%95%D7%97%D7%9C%D7%99%D7%9D-)  
   * [מדי לחות וטמפרטורה ](https://www.perfectreef.co.il/276824-%D7%9E%D7%93%D7%99-%D7%9C%D7%97%D7%95%D7%AA-%D7%95%D7%98%D7%9E%D7%A4%D7%A8%D7%98%D7%95%D7%A8%D7%94-)
* [אינדקס אלמוגים](https://www.perfectreef.co.il/472345-%D7%90%D7%99%D7%A0%D7%93%D7%A7%D7%A1-%D7%90%D7%9C%D7%9E%D7%95%D7%92%D7%99%D7%9D)  
   * [אלמוגים רכים](https://www.perfectreef.co.il/477638-%D7%90%D7%9C%D7%9E%D7%95%D7%92%D7%99%D7%9D-%D7%A8%D7%9B%D7%99%D7%9D)  
   * [אלמוגי SPS](https://www.perfectreef.co.il/479422-%D7%90%D7%9C%D7%9E%D7%95%D7%92%D7%99-SPS)  
   * [אלמוגי LPS](https://www.perfectreef.co.il/482427-%D7%90%D7%9C%D7%9E%D7%95%D7%92%D7%99-LPS)  
   * [פטריות וזאונטידים](https://www.perfectreef.co.il/490264-%D7%A4%D7%98%D7%A8%D7%99%D7%95%D7%AA-%D7%95%D7%96%D7%90%D7%95%D7%A0%D7%98%D7%99%D7%93%D7%99%D7%9D)
* אינדקס דגי נוי  
   * [דגי קרב](https://www.perfectreef.co.il/249896-%D7%93%D7%92%D7%99-%D7%A7%D7%A8%D7%91)  
   * [גרזנוניים](https://www.perfectreef.co.il/264505-%D7%92%D7%A8%D7%96%D7%A0%D7%95%D7%A0%D7%99%D7%99%D7%9D)  
   * [בוטיות](https://www.perfectreef.co.il/252475-%D7%91%D7%95%D7%98%D7%99%D7%95%D7%AA)  
   * [קיליפיש](https://www.perfectreef.co.il/264508-%D7%A7%D7%99%D7%9C%D7%99%D7%A4%D7%99%D7%A9)  
   * [גלופיש](https://www.perfectreef.co.il/264511-%D7%92%D7%9C%D7%95%D7%A4%D7%99%D7%A9)  
   * [קשתות](https://www.perfectreef.co.il/252486-%D7%A7%D7%A9%D7%AA%D7%95%D7%AA)  
   * [פלקו](https://www.perfectreef.co.il/253006-%D7%A4%D7%9C%D7%A7%D7%95)  
   * [רב סנפיר](https://www.perfectreef.co.il/250198-%D7%A8%D7%91-%D7%A1%D7%A0%D7%A4%D7%99%D7%A8)  
   * [ציקלידים אפריקאים](https://www.perfectreef.co.il/248694-%D7%A6%D7%99%D7%A7%D7%9C%D7%99%D7%93%D7%99%D7%9D-%D7%90%D7%A4%D7%A8%D7%99%D7%A7%D7%90%D7%99%D7%9D)  
   * [דיסקוסים](https://www.perfectreef.co.il/248704-%D7%93%D7%99%D7%A1%D7%A7%D7%95%D7%A1%D7%99%D7%9D)  
   * [צלופחים וסכינים](https://www.perfectreef.co.il/248705-%D7%A6%D7%9C%D7%95%D7%A4%D7%97%D7%99%D7%9D-%D7%95%D7%A1%D7%9B%D7%99%D7%A0%D7%99%D7%9D)  
   * [משריצי חיים](https://www.perfectreef.co.il/248706-%D7%9E%D7%A9%D7%A8%D7%99%D7%A6%D7%99-%D7%97%D7%99%D7%99%D7%9D)  
   * [קורידורסים](https://www.perfectreef.co.il/248707-%D7%A7%D7%95%D7%A8%D7%99%D7%93%D7%95%D7%A8%D7%A1%D7%99%D7%9D)  
   * [סקלארים](https://www.perfectreef.co.il/248708-%D7%A1%D7%A7%D7%9C%D7%90%D7%A8%D7%99%D7%9D)  
   * [ציקלידים אמריקאים](https://www.perfectreef.co.il/248709-%D7%A6%D7%99%D7%A7%D7%9C%D7%99%D7%93%D7%99%D7%9D-%D7%90%D7%9E%D7%A8%D7%99%D7%A7%D7%90%D7%99%D7%9D)  
   * [דגי טטרה](https://www.perfectreef.co.il/248710-%D7%93%D7%92%D7%99-%D7%98%D7%98%D7%A8%D7%94)  
   * [גורמים](https://www.perfectreef.co.il/252039-%D7%92%D7%95%D7%A8%D7%9E%D7%99%D7%9D)  
   * [חתוליים](https://www.perfectreef.co.il/250765-%D7%97%D7%AA%D7%95%D7%9C%D7%99%D7%99%D7%9D)  
   * [כרישים](https://www.perfectreef.co.il/251797-%D7%9B%D7%A8%D7%99%D7%A9%D7%99%D7%9D)  
   * [רזבורות](https://www.perfectreef.co.il/252640-%D7%A8%D7%96%D7%91%D7%95%D7%A8%D7%95%D7%AA)  
   * [דניוס ומינואס](https://www.perfectreef.co.il/264687-%D7%93%D7%A0%D7%99%D7%95%D7%A1-%D7%95%D7%9E%D7%99%D7%A0%D7%95%D7%90%D7%A1)  
   * [ארואנות](https://www.perfectreef.co.il/252670-%D7%90%D7%A8%D7%95%D7%90%D7%A0%D7%95%D7%AA)  
   * [דגי מים מתוקים למתחילים](https://www.perfectreef.co.il/264310-%D7%93%D7%92%D7%99-%D7%9E%D7%99%D7%9D-%D7%9E%D7%AA%D7%95%D7%A7%D7%99%D7%9D-%D7%9C%D7%9E%D7%AA%D7%97%D7%99%D7%9C%D7%99%D7%9D)  
   * [נפוחתיים](https://www.perfectreef.co.il/460960-%D7%A0%D7%A4%D7%95%D7%97%D7%AA%D7%99%D7%99%D7%9D)  
   * [מים מליחים](https://www.perfectreef.co.il/460996-%D7%9E%D7%99%D7%9D-%D7%9E%D7%9C%D7%99%D7%97%D7%99%D7%9D)
* [אינדקס מים מלוחים](https://www.perfectreef.co.il/248914-%D7%90%D7%99%D7%A0%D7%93%D7%A7%D7%A1-%D7%9E%D7%99%D7%9D-%D7%9E%D7%9C%D7%95%D7%97%D7%99%D7%9D)  
   * [עטלפים](https://www.perfectreef.co.il/254019-%D7%A2%D7%98%D7%9C%D7%A4%D7%99%D7%9D)  
   * [ראביט פיש](https://www.perfectreef.co.il/254237-%D7%A8%D7%90%D7%91%D7%99%D7%98-%D7%A4%D7%99%D7%A9)  
   * [דגי קופסה ופרה ](https://www.perfectreef.co.il/254495-%D7%93%D7%92%D7%99-%D7%A7%D7%95%D7%A4%D7%A1%D7%94-%D7%95%D7%A4%D7%A8%D7%94-)  
   * [פסאודוכרומיסים צבעוניים ](https://www.perfectreef.co.il/254570-%D7%A4%D7%A1%D7%90%D7%95%D7%93%D7%95%D7%9B%D7%A8%D7%95%D7%9E%D7%99%D7%A1%D7%99%D7%9D-%D7%A6%D7%91%D7%A2%D7%95%D7%A0%D7%99%D7%99%D7%9D-)  
   * [שושנונים](https://www.perfectreef.co.il/249452-%D7%A9%D7%95%D7%A9%D7%A0%D7%95%D7%A0%D7%99%D7%9D)  
   * [אנגלים ננסיים](https://www.perfectreef.co.il/249453-%D7%90%D7%A0%D7%92%D7%9C%D7%99%D7%9D-%D7%A0%D7%A0%D7%A1%D7%99%D7%99%D7%9D)  
   * [פזיות ](https://www.perfectreef.co.il/249454-%D7%A4%D7%96%D7%99%D7%95%D7%AA-)  
   * [בלנים](https://www.perfectreef.co.il/249455-%D7%91%D7%9C%D7%A0%D7%99%D7%9D)  
   * [פרפרונים](https://www.perfectreef.co.il/249456-%D7%A4%D7%A8%D7%A4%D7%A8%D7%95%D7%A0%D7%99%D7%9D)  
   * [אבובוניים](https://www.perfectreef.co.il/254065-%D7%90%D7%91%D7%95%D7%91%D7%95%D7%A0%D7%99%D7%99%D7%9D)  
   * [קרדינלים](https://www.perfectreef.co.il/249458-%D7%A7%D7%A8%D7%93%D7%99%D7%A0%D7%9C%D7%99%D7%9D)  
   * [אלמוגיות](https://www.perfectreef.co.il/249459-%D7%90%D7%9C%D7%9E%D7%95%D7%92%D7%99%D7%95%D7%AA)  
   * [דרגונטים](https://www.perfectreef.co.il/249460-%D7%93%D7%A8%D7%92%D7%95%D7%A0%D7%98%D7%99%D7%9D)  
   * [מורנות](https://www.perfectreef.co.il/249461-%D7%9E%D7%95%D7%A8%D7%A0%D7%95%D7%AA)  
   * [גובים](https://www.perfectreef.co.il/249462-%D7%92%D7%95%D7%91%D7%99%D7%9D)  
   * [לוקוסים](https://www.perfectreef.co.il/249463-%D7%9C%D7%95%D7%A7%D7%95%D7%A1%D7%99%D7%9D)  
   * [הוק-פישים](https://www.perfectreef.co.il/249464-%D7%94%D7%95%D7%A7-%D7%A4%D7%99%D7%A9%D7%99%D7%9D)  
   * [נתחנים ](https://www.perfectreef.co.il/249466-%D7%A0%D7%AA%D7%97%D7%A0%D7%99%D7%9D-)  
   * [נצרנים](https://www.perfectreef.co.il/249467-%D7%A0%D7%A6%D7%A8%D7%A0%D7%99%D7%9D)  
   * [אנגלים](https://www.perfectreef.co.il/248956-%D7%90%D7%A0%D7%92%D7%9C%D7%99%D7%9D)  
   * [חד קוציים](https://www.perfectreef.co.il/254928-%D7%97%D7%93-%D7%A7%D7%95%D7%A6%D7%99%D7%99%D7%9D)  
   * [ואראס ותוכינונים](https://www.perfectreef.co.il/254172-%D7%95%D7%90%D7%A8%D7%90%D7%A1-%D7%95%D7%AA%D7%95%D7%9B%D7%99%D7%A0%D7%95%D7%A0%D7%99%D7%9D)  
   * [כרומיסים](https://www.perfectreef.co.il/249457-%D7%9B%D7%A8%D7%95%D7%9E%D7%99%D7%A1%D7%99%D7%9D)  
   * [דגי מים מלוחים למתחילים](https://www.perfectreef.co.il/264340-%D7%93%D7%92%D7%99-%D7%9E%D7%99%D7%9D-%D7%9E%D7%9C%D7%95%D7%97%D7%99%D7%9D-%D7%9C%D7%9E%D7%AA%D7%97%D7%99%D7%9C%D7%99%D7%9D)
* [אינדקס צמחי מים](https://www.perfectreef.co.il/492970-%D7%90%D7%99%D7%A0%D7%93%D7%A7%D7%A1-%D7%A6%D7%9E%D7%97%D7%99-%D7%9E%D7%99%D7%9D)  
   * [צמחי הייטק](https://www.perfectreef.co.il/492975-%D7%A6%D7%9E%D7%97%D7%99-%D7%94%D7%99%D7%99%D7%98%D7%A7)  
   * [צמחי לאוטק](https://www.perfectreef.co.il/492983-%D7%A6%D7%9E%D7%97%D7%99-%D7%9C%D7%90%D7%95%D7%98%D7%A7)  
   * [צמחי בריכה](https://www.perfectreef.co.il/492998-%D7%A6%D7%9E%D7%97%D7%99-%D7%91%D7%A8%D7%99%D7%9B%D7%94)
* [מאמרים](https://www.perfectreef.co.il/245199-%D7%9E%D7%90%D7%9E%D7%A8%D7%99%D7%9D)
* [פח זבל](https://www.perfectreef.co.il/246106-%D7%A4%D7%97-%D7%96%D7%91%D7%9C)

### דברו איתנו

לקבלת ייעוץ ותמיכה מצוות המומחים

<tel:03-7443033> 

תתכתבו איתנו לפתיחת צ׳אט לייב בווטסאפ שלנו

 052-8508504

כתבו לנו שלחו לנו מייל בכל נושא 

[ perfectreef@gmail.com](mailto:perfectreef@gmail.com)

[**לינק** ](https://chat.whatsapp.com/L33KtuwFdr2BvzaWmUSfts)לקבוצת העדכונים השקטה של מחלקת המתוקים בוואטסאפ 

[**לינק** ](https://chat.whatsapp.com/C6bhb8WfILCB5aZum0l35N)לקבוצת העדכונים השקטה של מחלקת המלוחים בוואטסאפ 

קישור לוויז - [לחץ כאן](waze://?ll=32.0902.34.85781&navigate=yes)

כתובת החנות: אודם 5 פתח תקווה

**שעות פעילות:**

 ימים ראשון עד חמישי מ- 10:00 עד 19:00

יום ו מ-9.00 עד 15:00

יום שבת מ-9.00 עד 18:00

  
בערבי חג עד 15:00  
  
### מוזמנים לבקר אותנו גם ב

* [ ](https://www.facebook.com/Perfect-reef-%D7%A4%D7%A8%D7%A4%D7%A7%D7%98-%D7%A8%D7%99%D7%A3-133689333476552/)
* [ ](https://instagram.com/perfectreef?utm%5Fmedium=copy%5Flink)
* [ ](waze://?ll=32.0902.34.85781&navigate=yes)

![payment_icon]( https://d3m9l0v76dty0.cloudfront.net/system/photos/763642/original/198df48daf5575120726b88e07c840f8.png?1672741903 ) 

[ חנות אינטרנטית ![konimbo]( https://d3m9l0v76dty0.cloudfront.net/system/photos/665208/original/f0fe12e031df8d8053cb9a78d0a11163.png?1644240634 ) ](https://konimbo.co.il/) 

[ חנות אינטרנטית ](https://konimbo.co.il "חנות אינטרנטית") 

[ כל הקטגוריות ](#) 

* [דגים](https://www.perfectreef.co.il/246269-%D7%93%D7%92%D7%99%D7%9D)  
   * [אקווריומים ](https://www.perfectreef.co.il/246272-%D7%90%D7%A7%D7%95%D7%95%D7%A8%D7%99%D7%95%D7%9E%D7%99%D7%9D-)  
   * [משאבות מים](https://www.perfectreef.co.il/248063-%D7%9E%D7%A9%D7%90%D7%91%D7%95%D7%AA-%D7%9E%D7%99%D7%9D)  
   * [משאבות אוויר וציודן](https://www.perfectreef.co.il/248064-%D7%9E%D7%A9%D7%90%D7%91%D7%95%D7%AA-%D7%90%D7%95%D7%95%D7%99%D7%A8-%D7%95%D7%A6%D7%99%D7%95%D7%93%D7%9F)  
   * [משאבות גלים](https://www.perfectreef.co.il/248067-%D7%9E%D7%A9%D7%90%D7%91%D7%95%D7%AA-%D7%92%D7%9C%D7%99%D7%9D)  
   * [מדיות וסופחים ](https://www.perfectreef.co.il/246317-%D7%9E%D7%93%D7%99%D7%95%D7%AA-%D7%95%D7%A1%D7%95%D7%A4%D7%97%D7%99%D7%9D-)  
   * [תכשירים ותוספים לאקווריום](https://www.perfectreef.co.il/247103-%D7%AA%D7%9B%D7%A9%D7%99%D7%A8%D7%99%D7%9D-%D7%95%D7%AA%D7%95%D7%A1%D7%A4%D7%99%D7%9D-%D7%9C%D7%90%D7%A7%D7%95%D7%95%D7%A8%D7%99%D7%95%D7%9D)  
   * [תרופות דגים/אלמוגים](https://www.perfectreef.co.il/249826-%D7%AA%D7%A8%D7%95%D7%A4%D7%95%D7%AA-%D7%93%D7%92%D7%99%D7%9D-%D7%90%D7%9C%D7%9E%D7%95%D7%92%D7%99%D7%9D)  
   * [מגנטים, סקרפרים וציוד ניקוי](https://www.perfectreef.co.il/248058-%D7%9E%D7%92%D7%A0%D7%98%D7%99%D7%9D-%D7%A1%D7%A7%D7%A8%D7%A4%D7%A8%D7%99%D7%9D-%D7%95%D7%A6%D7%99%D7%95%D7%93-%D7%A0%D7%99%D7%A7%D7%95%D7%99)  
   * [גופי חימום ומדי חום](https://www.perfectreef.co.il/248065-%D7%92%D7%95%D7%A4%D7%99-%D7%97%D7%99%D7%9E%D7%95%D7%9D-%D7%95%D7%9E%D7%93%D7%99-%D7%97%D7%95%D7%9D)  
   * [מקררים ומאווררי קירור](https://www.perfectreef.co.il/248066-%D7%9E%D7%A7%D7%A8%D7%A8%D7%99%D7%9D-%D7%95%D7%9E%D7%90%D7%95%D7%95%D7%A8%D7%A8%D7%99-%D7%A7%D7%99%D7%A8%D7%95%D7%A8)  
   * [ערכות בדיקה](https://www.perfectreef.co.il/246276-%D7%A2%D7%A8%D7%9B%D7%95%D7%AA-%D7%91%D7%93%D7%99%D7%A7%D7%94)  
   * [ציוד נלווה](https://www.perfectreef.co.il/246332-%D7%A6%D7%99%D7%95%D7%93-%D7%A0%D7%9C%D7%95%D7%95%D7%94)  
   * [חומרי סינון לאקווריום](https://www.perfectreef.co.il/264646-%D7%97%D7%95%D7%9E%D7%A8%D7%99-%D7%A1%D7%99%D7%A0%D7%95%D7%9F-%D7%9C%D7%90%D7%A7%D7%95%D7%95%D7%A8%D7%99%D7%95%D7%9D)  
   * [מערכות UV ואוזון](https://www.perfectreef.co.il/248070-%D7%9E%D7%A2%D7%A8%D7%9B%D7%95%D7%AA-UV-%D7%95%D7%90%D7%95%D7%96%D7%95%D7%9F)  
   * [דקורציות](https://www.perfectreef.co.il/248069-%D7%93%D7%A7%D7%95%D7%A8%D7%A6%D7%99%D7%95%D7%AA)  
   * [גופי תאורה](https://www.perfectreef.co.il/248394-%D7%92%D7%95%D7%A4%D7%99-%D7%AA%D7%90%D7%95%D7%A8%D7%94)  
   * [סיליקון ודבקים לאקווריום](https://www.perfectreef.co.il/248398-%D7%A1%D7%99%D7%9C%D7%99%D7%A7%D7%95%D7%9F-%D7%95%D7%93%D7%91%D7%A7%D7%99%D7%9D-%D7%9C%D7%90%D7%A7%D7%95%D7%95%D7%A8%D7%99%D7%95%D7%9D)  
   * [מצעים וחצצים](https://www.perfectreef.co.il/248811-%D7%9E%D7%A6%D7%A2%D7%99%D7%9D-%D7%95%D7%97%D7%A6%D7%A6%D7%99%D7%9D)  
   * [מערכות אוסמוזה וציודן](https://www.perfectreef.co.il/248820-%D7%9E%D7%A2%D7%A8%D7%9B%D7%95%D7%AA-%D7%90%D7%95%D7%A1%D7%9E%D7%95%D7%96%D7%94-%D7%95%D7%A6%D7%99%D7%95%D7%93%D7%9F)  
   * [מאכילים אוטומטיים](https://www.perfectreef.co.il/248821-%D7%9E%D7%90%D7%9B%D7%99%D7%9C%D7%99%D7%9D-%D7%90%D7%95%D7%98%D7%95%D7%9E%D7%98%D7%99%D7%99%D7%9D)  
   * [צינורות גמישים ומחברים](https://www.perfectreef.co.il/248823-%D7%A6%D7%99%D7%A0%D7%95%D7%A8%D7%95%D7%AA-%D7%92%D7%9E%D7%99%D7%A9%D7%99%D7%9D-%D7%95%D7%9E%D7%97%D7%91%D7%A8%D7%99%D7%9D)  
   * [משאבות מינון](https://www.perfectreef.co.il/295372-%D7%9E%D7%A9%D7%90%D7%91%D7%95%D7%AA-%D7%9E%D7%99%D7%A0%D7%95%D7%9F)  
   * [שואבי רפש](https://www.perfectreef.co.il/248068-%D7%A9%D7%95%D7%90%D7%91%D7%99-%D7%A8%D7%A4%D7%A9)  
   * [תאי השרצה, אקלום ומלכודות ](https://www.perfectreef.co.il/354094-%D7%AA%D7%90%D7%99-%D7%94%D7%A9%D7%A8%D7%A6%D7%94-%D7%90%D7%A7%D7%9C%D7%95%D7%9D-%D7%95%D7%9E%D7%9C%D7%9B%D7%95%D7%93%D7%95%D7%AA-)  
   * [מערכות פיצוי אידוי ](https://www.perfectreef.co.il/252927-%D7%9E%D7%A2%D7%A8%D7%9B%D7%95%D7%AA-%D7%A4%D7%99%D7%A6%D7%95%D7%99-%D7%90%D7%99%D7%93%D7%95%D7%99-)  
   * [חלקי צנרת PVC](https://www.perfectreef.co.il/248396-%D7%97%D7%9C%D7%A7%D7%99-%D7%A6%D7%A0%D7%A8%D7%AA-PVC)  
   * מחלקת מים מלוחים  
   * [פורקי חלבונים וקולונות](https://www.perfectreef.co.il/246295-%D7%A4%D7%95%D7%A8%D7%A7%D7%99-%D7%97%D7%9C%D7%91%D7%95%D7%A0%D7%99%D7%9D-%D7%95%D7%A7%D7%95%D7%9C%D7%95%D7%A0%D7%95%D7%AA)  
   * [מזונות לדגי ים ](https://www.perfectreef.co.il/247100-%D7%9E%D7%96%D7%95%D7%A0%D7%95%D7%AA-%D7%9C%D7%93%D7%92%D7%99-%D7%99%D7%9D-)  
   * [תכשירים ותוספים למלוחים](https://www.perfectreef.co.il/246268-%D7%AA%D7%9B%D7%A9%D7%99%D7%A8%D7%99%D7%9D-%D7%95%D7%AA%D7%95%D7%A1%D7%A4%D7%99%D7%9D-%D7%9C%D7%9E%D7%9C%D7%95%D7%97%D7%99%D7%9D)  
   * [מזונות אלמוגים וחסרי חוליות](https://www.perfectreef.co.il/734248-%D7%9E%D7%96%D7%95%D7%A0%D7%95%D7%AA-%D7%90%D7%9C%D7%9E%D7%95%D7%92%D7%99%D7%9D-%D7%95%D7%97%D7%A1%D7%A8%D7%99-%D7%97%D7%95%D7%9C%D7%99%D7%95%D7%AA)  
   * [מלחים ](https://www.perfectreef.co.il/265540-%D7%9E%D7%9C%D7%97%D7%99%D7%9D-)  
   * [מדי מליחות ועזרים למלוחים](https://www.perfectreef.co.il/248059-%D7%9E%D7%93%D7%99-%D7%9E%D7%9C%D7%99%D7%97%D7%95%D7%AA-%D7%95%D7%A2%D7%96%D7%A8%D7%99%D7%9D-%D7%9C%D7%9E%D7%9C%D7%95%D7%97%D7%99%D7%9D)  
   * [סופחים למלוחים](https://www.perfectreef.co.il/265379-%D7%A1%D7%95%D7%A4%D7%97%D7%99%D7%9D-%D7%9C%D7%9E%D7%9C%D7%95%D7%97%D7%99%D7%9D)  
   * מחלקת מים מתוקים  
   * [פילטרים פנימיים](https://www.perfectreef.co.il/247102-%D7%A4%D7%99%D7%9C%D7%98%D7%A8%D7%99%D7%9D-%D7%A4%D7%A0%D7%99%D7%9E%D7%99%D7%99%D7%9D)  
   * [פילטרים חיצוניים](https://www.perfectreef.co.il/248060-%D7%A4%D7%99%D7%9C%D7%98%D7%A8%D7%99%D7%9D-%D7%97%D7%99%D7%A6%D7%95%D7%A0%D7%99%D7%99%D7%9D)  
   * [מזונות דגים וחסרי חוליות](https://www.perfectreef.co.il/246280-%D7%9E%D7%96%D7%95%D7%A0%D7%95%D7%AA-%D7%93%D7%92%D7%99%D7%9D-%D7%95%D7%97%D7%A1%D7%A8%D7%99-%D7%97%D7%95%D7%9C%D7%99%D7%95%D7%AA)  
   * [תכשירים ותוספים לאקווריום צמחיה ](https://www.perfectreef.co.il/246296-%D7%AA%D7%9B%D7%A9%D7%99%D7%A8%D7%99%D7%9D-%D7%95%D7%AA%D7%95%D7%A1%D7%A4%D7%99%D7%9D-%D7%9C%D7%90%D7%A7%D7%95%D7%95%D7%A8%D7%99%D7%95%D7%9D-%D7%A6%D7%9E%D7%97%D7%99%D7%94-)  
   * [ציוד לאקווריום צמחיה](https://www.perfectreef.co.il/257470-%D7%A6%D7%99%D7%95%D7%93-%D7%9C%D7%90%D7%A7%D7%95%D7%95%D7%A8%D7%99%D7%95%D7%9D-%D7%A6%D7%9E%D7%97%D7%99%D7%94)  
   * [ספוגים וחלקי חילוף לפילטרים](https://www.perfectreef.co.il/257284-%D7%A1%D7%A4%D7%95%D7%92%D7%99%D7%9D-%D7%95%D7%97%D7%9C%D7%A7%D7%99-%D7%97%D7%99%D7%9C%D7%95%D7%A3-%D7%9C%D7%A4%D7%99%D7%9C%D7%98%D7%A8%D7%99%D7%9D)  
   * [חלקי חילוף לג'אוול](https://www.perfectreef.co.il/248062-%D7%97%D7%9C%D7%A7%D7%99-%D7%97%D7%99%D7%9C%D7%95%D7%A3-%D7%9C%D7%92-%D7%90%D7%95%D7%95%D7%9C)  
   * מחלקת בריכות נוי  
   * [משאבות מים לבריכות](https://www.perfectreef.co.il/248072-%D7%9E%D7%A9%D7%90%D7%91%D7%95%D7%AA-%D7%9E%D7%99%D7%9D-%D7%9C%D7%91%D7%A8%D7%99%D7%9B%D7%95%D7%AA)  
   * [בריכות נוי וציודם ](https://www.perfectreef.co.il/246300-%D7%91%D7%A8%D7%99%D7%9B%D7%95%D7%AA-%D7%A0%D7%95%D7%99-%D7%95%D7%A6%D7%99%D7%95%D7%93%D7%9D-)  
   * [פילטרים לבריכות](https://www.perfectreef.co.il/248071-%D7%A4%D7%99%D7%9C%D7%98%D7%A8%D7%99%D7%9D-%D7%9C%D7%91%D7%A8%D7%99%D7%9B%D7%95%D7%AA)  
   * [תאורות לבריכות](https://www.perfectreef.co.il/248073-%D7%AA%D7%90%D7%95%D7%A8%D7%95%D7%AA-%D7%9C%D7%91%D7%A8%D7%99%D7%9B%D7%95%D7%AA)  
   * [תכשירים ותוספים לבריכות](https://www.perfectreef.co.il/252104-%D7%AA%D7%9B%D7%A9%D7%99%D7%A8%D7%99%D7%9D-%D7%95%D7%AA%D7%95%D7%A1%D7%A4%D7%99%D7%9D-%D7%9C%D7%91%D7%A8%D7%99%D7%9B%D7%95%D7%AA)  
   * [מזונות דגי בריכה](https://www.perfectreef.co.il/254849-%D7%9E%D7%96%D7%95%D7%A0%D7%95%D7%AA-%D7%93%D7%92%D7%99-%D7%91%D7%A8%D7%99%D7%9B%D7%94)
* [כלבים](https://www.perfectreef.co.il/246271-%D7%9B%D7%9C%D7%91%D7%99%D7%9D)  
   * [מזון יבש כלבים ](https://www.perfectreef.co.il/246279-%D7%9E%D7%96%D7%95%D7%9F-%D7%99%D7%91%D7%A9-%D7%9B%D7%9C%D7%91%D7%99%D7%9D-)  
   * [מזון רפואי כלבים](https://www.perfectreef.co.il/246333-%D7%9E%D7%96%D7%95%D7%9F-%D7%A8%D7%A4%D7%95%D7%90%D7%99-%D7%9B%D7%9C%D7%91%D7%99%D7%9D)  
   * [עצמות דחוסות וקשר כלבים](https://www.perfectreef.co.il/246299-%D7%A2%D7%A6%D7%9E%D7%95%D7%AA-%D7%93%D7%97%D7%95%D7%A1%D7%95%D7%AA-%D7%95%D7%A7%D7%A9%D7%A8-%D7%9B%D7%9C%D7%91%D7%99%D7%9D)  
   * [חטיפי כלבים ](https://www.perfectreef.co.il/246286-%D7%97%D7%98%D7%99%D7%A4%D7%99-%D7%9B%D7%9C%D7%91%D7%99%D7%9D-)  
   * [שימורים ומעדני כלבים](https://www.perfectreef.co.il/246273-%D7%A9%D7%99%D7%9E%D7%95%D7%A8%D7%99%D7%9D-%D7%95%D7%9E%D7%A2%D7%93%D7%A0%D7%99-%D7%9B%D7%9C%D7%91%D7%99%D7%9D)  
   * [תוספי תזונה כלבים](https://www.perfectreef.co.il/246310-%D7%AA%D7%95%D7%A1%D7%A4%D7%99-%D7%AA%D7%96%D7%95%D7%A0%D7%94-%D7%9B%D7%9C%D7%91%D7%99%D7%9D)  
   * [צעצועי כלבים](https://www.perfectreef.co.il/246334-%D7%A6%D7%A2%D7%A6%D7%95%D7%A2%D7%99-%D7%9B%D7%9C%D7%91%D7%99%D7%9D)  
   * [כלי אוכל ושתיה כלבים](https://www.perfectreef.co.il/246298-%D7%9B%D7%9C%D7%99-%D7%90%D7%95%D7%9B%D7%9C-%D7%95%D7%A9%D7%AA%D7%99%D7%94-%D7%9B%D7%9C%D7%91%D7%99%D7%9D)  
   * [מוצרי טיפוח לכלבים](https://www.perfectreef.co.il/246284-%D7%9E%D7%95%D7%A6%D7%A8%D7%99-%D7%98%D7%99%D7%A4%D7%95%D7%97-%D7%9C%D7%9B%D7%9C%D7%91%D7%99%D7%9D)  
   * [מוצרי היגיינה לכלבים](https://www.perfectreef.co.il/272962-%D7%9E%D7%95%D7%A6%D7%A8%D7%99-%D7%94%D7%99%D7%92%D7%99%D7%99%D7%A0%D7%94-%D7%9C%D7%9B%D7%9C%D7%91%D7%99%D7%9D)  
   * [מיטות ומזרני כלבים](https://www.perfectreef.co.il/246293-%D7%9E%D7%99%D7%98%D7%95%D7%AA-%D7%95%D7%9E%D7%96%D7%A8%D7%A0%D7%99-%D7%9B%D7%9C%D7%91%D7%99%D7%9D)  
   * [קולרים ורצועות כלבים](https://www.perfectreef.co.il/246283-%D7%A7%D7%95%D7%9C%D7%A8%D7%99%D7%9D-%D7%95%D7%A8%D7%A6%D7%95%D7%A2%D7%95%D7%AA-%D7%9B%D7%9C%D7%91%D7%99%D7%9D)  
   * [כלובי נשיאה ותיקי כלבים](https://www.perfectreef.co.il/246270-%D7%9B%D7%9C%D7%95%D7%91%D7%99-%D7%A0%D7%A9%D7%99%D7%90%D7%94-%D7%95%D7%AA%D7%99%D7%A7%D7%99-%D7%9B%D7%9C%D7%91%D7%99%D7%9D)  
   * [ציוד ותכשירי אילוף ומשמעת כלבים](https://www.perfectreef.co.il/246312-%D7%A6%D7%99%D7%95%D7%93-%D7%95%D7%AA%D7%9B%D7%A9%D7%99%D7%A8%D7%99-%D7%90%D7%99%D7%9C%D7%95%D7%A3-%D7%95%D7%9E%D7%A9%D7%9E%D7%A2%D7%AA-%D7%9B%D7%9C%D7%91%D7%99%D7%9D)  
   * [כלובים וגדרות אילוף כלבים](https://www.perfectreef.co.il/246337-%D7%9B%D7%9C%D7%95%D7%91%D7%99%D7%9D-%D7%95%D7%92%D7%93%D7%A8%D7%95%D7%AA-%D7%90%D7%99%D7%9C%D7%95%D7%A3-%D7%9B%D7%9C%D7%91%D7%99%D7%9D)  
   * [מרחיקי כלבים ](https://www.perfectreef.co.il/246314-%D7%9E%D7%A8%D7%97%D7%99%D7%A7%D7%99-%D7%9B%D7%9C%D7%91%D7%99%D7%9D-)  
   * [מוצרי הדברה כלבים](https://www.perfectreef.co.il/246285-%D7%9E%D7%95%D7%A6%D7%A8%D7%99-%D7%94%D7%93%D7%91%D7%A8%D7%94-%D7%9B%D7%9C%D7%91%D7%99%D7%9D)  
   * [מזרקות מים לשתיה כלבים](https://www.perfectreef.co.il/262982-%D7%9E%D7%96%D7%A8%D7%A7%D7%95%D7%AA-%D7%9E%D7%99%D7%9D-%D7%9C%D7%A9%D7%AA%D7%99%D7%94-%D7%9B%D7%9C%D7%91%D7%99%D7%9D)
* [חתולים](https://www.perfectreef.co.il/246275-%D7%97%D7%AA%D7%95%D7%9C%D7%99%D7%9D)  
   * [מזון יבש חתולים](https://www.perfectreef.co.il/246278-%D7%9E%D7%96%D7%95%D7%9F-%D7%99%D7%91%D7%A9-%D7%97%D7%AA%D7%95%D7%9C%D7%99%D7%9D)  
   * [שימורים ומעדני חתולים](https://www.perfectreef.co.il/248504-%D7%A9%D7%99%D7%9E%D7%95%D7%A8%D7%99%D7%9D-%D7%95%D7%9E%D7%A2%D7%93%D7%A0%D7%99-%D7%97%D7%AA%D7%95%D7%9C%D7%99%D7%9D)  
   * [מוצרי הדברה לחתולים](https://www.perfectreef.co.il/256442-%D7%9E%D7%95%D7%A6%D7%A8%D7%99-%D7%94%D7%93%D7%91%D7%A8%D7%94-%D7%9C%D7%97%D7%AA%D7%95%D7%9C%D7%99%D7%9D)  
   * [חול חתולים ](https://www.perfectreef.co.il/246294-%D7%97%D7%95%D7%9C-%D7%97%D7%AA%D7%95%D7%9C%D7%99%D7%9D-)  
   * [שירותי חתולים](https://www.perfectreef.co.il/246307-%D7%A9%D7%99%D7%A8%D7%95%D7%AA%D7%99-%D7%97%D7%AA%D7%95%D7%9C%D7%99%D7%9D)  
   * [מגרדות חתולים](https://www.perfectreef.co.il/246289-%D7%9E%D7%92%D7%A8%D7%93%D7%95%D7%AA-%D7%97%D7%AA%D7%95%D7%9C%D7%99%D7%9D)  
   * [חטיפי חתולים](https://www.perfectreef.co.il/246321-%D7%97%D7%98%D7%99%D7%A4%D7%99-%D7%97%D7%AA%D7%95%D7%9C%D7%99%D7%9D)  
   * [תוספי חתולים](https://www.perfectreef.co.il/248179-%D7%AA%D7%95%D7%A1%D7%A4%D7%99-%D7%97%D7%AA%D7%95%D7%9C%D7%99%D7%9D)  
   * [מוצרי היגיינה וטיפוח חתולים](https://www.perfectreef.co.il/248229-%D7%9E%D7%95%D7%A6%D7%A8%D7%99-%D7%94%D7%99%D7%92%D7%99%D7%99%D7%A0%D7%94-%D7%95%D7%98%D7%99%D7%A4%D7%95%D7%97-%D7%97%D7%AA%D7%95%D7%9C%D7%99%D7%9D)  
   * [קולרי חתולים](https://www.perfectreef.co.il/246325-%D7%A7%D7%95%D7%9C%D7%A8%D7%99-%D7%97%D7%AA%D7%95%D7%9C%D7%99%D7%9D)  
   * [צעצועי חתולים](https://www.perfectreef.co.il/246303-%D7%A6%D7%A2%D7%A6%D7%95%D7%A2%D7%99-%D7%97%D7%AA%D7%95%D7%9C%D7%99%D7%9D)  
   * [מנשאות וכלובי חתולים](https://www.perfectreef.co.il/246297-%D7%9E%D7%A0%D7%A9%D7%90%D7%95%D7%AA-%D7%95%D7%9B%D7%9C%D7%95%D7%91%D7%99-%D7%97%D7%AA%D7%95%D7%9C%D7%99%D7%9D)  
   * [כלי אוכל ושתיה חתולים](https://www.perfectreef.co.il/246274-%D7%9B%D7%9C%D7%99-%D7%90%D7%95%D7%9B%D7%9C-%D7%95%D7%A9%D7%AA%D7%99%D7%94-%D7%97%D7%AA%D7%95%D7%9C%D7%99%D7%9D)  
   * [מרחיקי חתולים ](https://www.perfectreef.co.il/246326-%D7%9E%D7%A8%D7%97%D7%99%D7%A7%D7%99-%D7%97%D7%AA%D7%95%D7%9C%D7%99%D7%9D-)  
   * [מיטות ומזרני חתולים](https://www.perfectreef.co.il/246328-%D7%9E%D7%99%D7%98%D7%95%D7%AA-%D7%95%D7%9E%D7%96%D7%A8%D7%A0%D7%99-%D7%97%D7%AA%D7%95%D7%9C%D7%99%D7%9D)  
   * [מזון רפואי חתולים ](https://www.perfectreef.co.il/246327-%D7%9E%D7%96%D7%95%D7%9F-%D7%A8%D7%A4%D7%95%D7%90%D7%99-%D7%97%D7%AA%D7%95%D7%9C%D7%99%D7%9D-)  
   * [מזרקות מים לשתיה לחתולים](https://www.perfectreef.co.il/262932-%D7%9E%D7%96%D7%A8%D7%A7%D7%95%D7%AA-%D7%9E%D7%99%D7%9D-%D7%9C%D7%A9%D7%AA%D7%99%D7%94-%D7%9C%D7%97%D7%AA%D7%95%D7%9C%D7%99%D7%9D)
* [ציפורים ](https://www.perfectreef.co.il/246282-%D7%A6%D7%99%D7%A4%D7%95%D7%A8%D7%99%D7%9D-)  
   * [כלובי ציפורים](https://www.perfectreef.co.il/248235-%D7%9B%D7%9C%D7%95%D7%91%D7%99-%D7%A6%D7%99%D7%A4%D7%95%D7%A8%D7%99%D7%9D)  
   * [מזון ציפורים](https://www.perfectreef.co.il/246292-%D7%9E%D7%96%D7%95%D7%9F-%D7%A6%D7%99%D7%A4%D7%95%D7%A8%D7%99%D7%9D)  
   * [ חטיפי ציפורים](https://www.perfectreef.co.il/248164--%D7%97%D7%98%D7%99%D7%A4%D7%99-%D7%A6%D7%99%D7%A4%D7%95%D7%A8%D7%99%D7%9D)  
   * [תוספי ציפורים](https://www.perfectreef.co.il/246323-%D7%AA%D7%95%D7%A1%D7%A4%D7%99-%D7%A6%D7%99%D7%A4%D7%95%D7%A8%D7%99%D7%9D)  
   * [צעצועים ואביזרי ציפורים](https://www.perfectreef.co.il/246281-%D7%A6%D7%A2%D7%A6%D7%95%D7%A2%D7%99%D7%9D-%D7%95%D7%90%D7%91%D7%99%D7%96%D7%A8%D7%99-%D7%A6%D7%99%D7%A4%D7%95%D7%A8%D7%99%D7%9D)
* [מכרסמים ](https://www.perfectreef.co.il/246288-%D7%9E%D7%9B%D7%A8%D7%A1%D7%9E%D7%99%D7%9D-)  
   * [כלובי מכרסמים](https://www.perfectreef.co.il/246291-%D7%9B%D7%9C%D7%95%D7%91%D7%99-%D7%9E%D7%9B%D7%A8%D7%A1%D7%9E%D7%99%D7%9D)  
   * [חטיפים ותוספים מכרסמים](https://www.perfectreef.co.il/246287-%D7%97%D7%98%D7%99%D7%A4%D7%99%D7%9D-%D7%95%D7%AA%D7%95%D7%A1%D7%A4%D7%99%D7%9D-%D7%9E%D7%9B%D7%A8%D7%A1%D7%9E%D7%99%D7%9D)  
   * [בתי מחסה למכרסמים](https://www.perfectreef.co.il/348540-%D7%91%D7%AA%D7%99-%D7%9E%D7%97%D7%A1%D7%94-%D7%9C%D7%9E%D7%9B%D7%A8%D7%A1%D7%9E%D7%99%D7%9D)  
   * [כלי אוכל ושתיה למכרסמים](https://www.perfectreef.co.il/349107-%D7%9B%D7%9C%D7%99-%D7%90%D7%95%D7%9B%D7%9C-%D7%95%D7%A9%D7%AA%D7%99%D7%94-%D7%9C%D7%9E%D7%9B%D7%A8%D7%A1%D7%9E%D7%99%D7%9D)  
   * [מזון מכרסמים](https://www.perfectreef.co.il/248168-%D7%9E%D7%96%D7%95%D7%9F-%D7%9E%D7%9B%D7%A8%D7%A1%D7%9E%D7%99%D7%9D)  
   * [מצע מכרסמים ](https://www.perfectreef.co.il/246308-%D7%9E%D7%A6%D7%A2-%D7%9E%D7%9B%D7%A8%D7%A1%D7%9E%D7%99%D7%9D-)  
   * [צעצועי מכרסמים](https://www.perfectreef.co.il/246324-%D7%A6%D7%A2%D7%A6%D7%95%D7%A2%D7%99-%D7%9E%D7%9B%D7%A8%D7%A1%D7%9E%D7%99%D7%9D)  
   * [מוצרי היגיינה וטיפוח מכרסמים](https://www.perfectreef.co.il/248230-%D7%9E%D7%95%D7%A6%D7%A8%D7%99-%D7%94%D7%99%D7%92%D7%99%D7%99%D7%A0%D7%94-%D7%95%D7%98%D7%99%D7%A4%D7%95%D7%97-%D7%9E%D7%9B%D7%A8%D7%A1%D7%9E%D7%99%D7%9D)
* [זוחלים ](https://www.perfectreef.co.il/246306-%D7%96%D7%95%D7%97%D7%9C%D7%99%D7%9D-)  
   * [טרריומים ופולידריומים](https://www.perfectreef.co.il/246305-%D7%98%D7%A8%D7%A8%D7%99%D7%95%D7%9E%D7%99%D7%9D-%D7%95%D7%A4%D7%95%D7%9C%D7%99%D7%93%D7%A8%D7%99%D7%95%D7%9E%D7%99%D7%9D)  
   * [מצע זוחלים](https://www.perfectreef.co.il/246329-%D7%9E%D7%A6%D7%A2-%D7%96%D7%95%D7%97%D7%9C%D7%99%D7%9D)  
   * [שטיחים אקולוגיים](https://www.perfectreef.co.il/261752-%D7%A9%D7%98%D7%99%D7%97%D7%99%D7%9D-%D7%90%D7%A7%D7%95%D7%9C%D7%95%D7%92%D7%99%D7%99%D7%9D)  
   * [תאורת זוחלים](https://www.perfectreef.co.il/246313-%D7%AA%D7%90%D7%95%D7%A8%D7%AA-%D7%96%D7%95%D7%97%D7%9C%D7%99%D7%9D)  
   * [כלי האכלה זוחלים](https://www.perfectreef.co.il/248097-%D7%9B%D7%9C%D7%99-%D7%94%D7%90%D7%9B%D7%9C%D7%94-%D7%96%D7%95%D7%97%D7%9C%D7%99%D7%9D)  
   * [דקורציות ומחסה לזוחלים](https://www.perfectreef.co.il/246335-%D7%93%D7%A7%D7%95%D7%A8%D7%A6%D7%99%D7%95%D7%AA-%D7%95%D7%9E%D7%97%D7%A1%D7%94-%D7%9C%D7%96%D7%95%D7%97%D7%9C%D7%99%D7%9D)  
   * [מוצרי חימום זוחלים](https://www.perfectreef.co.il/246336-%D7%9E%D7%95%D7%A6%D7%A8%D7%99-%D7%97%D7%99%D7%9E%D7%95%D7%9D-%D7%96%D7%95%D7%97%D7%9C%D7%99%D7%9D)  
   * [אבני חימום לזוחלים](https://www.perfectreef.co.il/257998-%D7%90%D7%91%D7%A0%D7%99-%D7%97%D7%99%D7%9E%D7%95%D7%9D-%D7%9C%D7%96%D7%95%D7%97%D7%9C%D7%99%D7%9D)  
   * [ציוד זוחלים ](https://www.perfectreef.co.il/246331-%D7%A6%D7%99%D7%95%D7%93-%D7%96%D7%95%D7%97%D7%9C%D7%99%D7%9D-)  
   * [מדי לחות וטמפרטורה ](https://www.perfectreef.co.il/276824-%D7%9E%D7%93%D7%99-%D7%9C%D7%97%D7%95%D7%AA-%D7%95%D7%98%D7%9E%D7%A4%D7%A8%D7%98%D7%95%D7%A8%D7%94-)
* [אינדקס אלמוגים](https://www.perfectreef.co.il/472345-%D7%90%D7%99%D7%A0%D7%93%D7%A7%D7%A1-%D7%90%D7%9C%D7%9E%D7%95%D7%92%D7%99%D7%9D)  
   * [אלמוגים רכים](https://www.perfectreef.co.il/477638-%D7%90%D7%9C%D7%9E%D7%95%D7%92%D7%99%D7%9D-%D7%A8%D7%9B%D7%99%D7%9D)  
   * [אלמוגי SPS](https://www.perfectreef.co.il/479422-%D7%90%D7%9C%D7%9E%D7%95%D7%92%D7%99-SPS)  
   * [אלמוגי LPS](https://www.perfectreef.co.il/482427-%D7%90%D7%9C%D7%9E%D7%95%D7%92%D7%99-LPS)  
   * [פטריות וזאונטידים](https://www.perfectreef.co.il/490264-%D7%A4%D7%98%D7%A8%D7%99%D7%95%D7%AA-%D7%95%D7%96%D7%90%D7%95%D7%A0%D7%98%D7%99%D7%93%D7%99%D7%9D)
* [אינדקס דגי נוי ](https://www.perfectreef.co.il/248692-%D7%90%D7%99%D7%A0%D7%93%D7%A7%D7%A1-%D7%93%D7%92%D7%99-%D7%A0%D7%95%D7%99-)  
   * [דגי קרב](https://www.perfectreef.co.il/249896-%D7%93%D7%92%D7%99-%D7%A7%D7%A8%D7%91)  
   * [גרזנוניים](https://www.perfectreef.co.il/264505-%D7%92%D7%A8%D7%96%D7%A0%D7%95%D7%A0%D7%99%D7%99%D7%9D)  
   * [בוטיות](https://www.perfectreef.co.il/252475-%D7%91%D7%95%D7%98%D7%99%D7%95%D7%AA)  
   * [קיליפיש](https://www.perfectreef.co.il/264508-%D7%A7%D7%99%D7%9C%D7%99%D7%A4%D7%99%D7%A9)  
   * [גלופיש](https://www.perfectreef.co.il/264511-%D7%92%D7%9C%D7%95%D7%A4%D7%99%D7%A9)  
   * [קשתות](https://www.perfectreef.co.il/252486-%D7%A7%D7%A9%D7%AA%D7%95%D7%AA)  
   * [פלקו](https://www.perfectreef.co.il/253006-%D7%A4%D7%9C%D7%A7%D7%95)  
   * [רב סנפיר](https://www.perfectreef.co.il/250198-%D7%A8%D7%91-%D7%A1%D7%A0%D7%A4%D7%99%D7%A8)  
   * [ציקלידים אפריקאים](https://www.perfectreef.co.il/248694-%D7%A6%D7%99%D7%A7%D7%9C%D7%99%D7%93%D7%99%D7%9D-%D7%90%D7%A4%D7%A8%D7%99%D7%A7%D7%90%D7%99%D7%9D)  
   * [דיסקוסים](https://www.perfectreef.co.il/248704-%D7%93%D7%99%D7%A1%D7%A7%D7%95%D7%A1%D7%99%D7%9D)  
   * [צלופחים וסכינים](https://www.perfectreef.co.il/248705-%D7%A6%D7%9C%D7%95%D7%A4%D7%97%D7%99%D7%9D-%D7%95%D7%A1%D7%9B%D7%99%D7%A0%D7%99%D7%9D)  
   * [משריצי חיים](https://www.perfectreef.co.il/248706-%D7%9E%D7%A9%D7%A8%D7%99%D7%A6%D7%99-%D7%97%D7%99%D7%99%D7%9D)  
   * [קורידורסים](https://www.perfectreef.co.il/248707-%D7%A7%D7%95%D7%A8%D7%99%D7%93%D7%95%D7%A8%D7%A1%D7%99%D7%9D)  
   * [סקלארים](https://www.perfectreef.co.il/248708-%D7%A1%D7%A7%D7%9C%D7%90%D7%A8%D7%99%D7%9D)  
   * [ציקלידים אמריקאים](https://www.perfectreef.co.il/248709-%D7%A6%D7%99%D7%A7%D7%9C%D7%99%D7%93%D7%99%D7%9D-%D7%90%D7%9E%D7%A8%D7%99%D7%A7%D7%90%D7%99%D7%9D)  
   * [דגי טטרה](https://www.perfectreef.co.il/248710-%D7%93%D7%92%D7%99-%D7%98%D7%98%D7%A8%D7%94)  
   * [גורמים](https://www.perfectreef.co.il/252039-%D7%92%D7%95%D7%A8%D7%9E%D7%99%D7%9D)  
   * [חתוליים](https://www.perfectreef.co.il/250765-%D7%97%D7%AA%D7%95%D7%9C%D7%99%D7%99%D7%9D)  
   * [כרישים](https://www.perfectreef.co.il/251797-%D7%9B%D7%A8%D7%99%D7%A9%D7%99%D7%9D)  
   * [רזבורות](https://www.perfectreef.co.il/252640-%D7%A8%D7%96%D7%91%D7%95%D7%A8%D7%95%D7%AA)  
   * [דניוס ומינואס](https://www.perfectreef.co.il/264687-%D7%93%D7%A0%D7%99%D7%95%D7%A1-%D7%95%D7%9E%D7%99%D7%A0%D7%95%D7%90%D7%A1)  
   * [ארואנות](https://www.perfectreef.co.il/252670-%D7%90%D7%A8%D7%95%D7%90%D7%A0%D7%95%D7%AA)  
   * [דגי מים מתוקים למתחילים](https://www.perfectreef.co.il/264310-%D7%93%D7%92%D7%99-%D7%9E%D7%99%D7%9D-%D7%9E%D7%AA%D7%95%D7%A7%D7%99%D7%9D-%D7%9C%D7%9E%D7%AA%D7%97%D7%99%D7%9C%D7%99%D7%9D)  
   * [נפוחתיים](https://www.perfectreef.co.il/460960-%D7%A0%D7%A4%D7%95%D7%97%D7%AA%D7%99%D7%99%D7%9D)  
   * [מים מליחים](https://www.perfectreef.co.il/460996-%D7%9E%D7%99%D7%9D-%D7%9E%D7%9C%D7%99%D7%97%D7%99%D7%9D)
* [אינדקס מים מלוחים](https://www.perfectreef.co.il/248914-%D7%90%D7%99%D7%A0%D7%93%D7%A7%D7%A1-%D7%9E%D7%99%D7%9D-%D7%9E%D7%9C%D7%95%D7%97%D7%99%D7%9D)  
   * [עטלפים](https://www.perfectreef.co.il/254019-%D7%A2%D7%98%D7%9C%D7%A4%D7%99%D7%9D)  
   * [ראביט פיש](https://www.perfectreef.co.il/254237-%D7%A8%D7%90%D7%91%D7%99%D7%98-%D7%A4%D7%99%D7%A9)  
   * [דגי קופסה ופרה ](https://www.perfectreef.co.il/254495-%D7%93%D7%92%D7%99-%D7%A7%D7%95%D7%A4%D7%A1%D7%94-%D7%95%D7%A4%D7%A8%D7%94-)  
   * [פסאודוכרומיסים צבעוניים ](https://www.perfectreef.co.il/254570-%D7%A4%D7%A1%D7%90%D7%95%D7%93%D7%95%D7%9B%D7%A8%D7%95%D7%9E%D7%99%D7%A1%D7%99%D7%9D-%D7%A6%D7%91%D7%A2%D7%95%D7%A0%D7%99%D7%99%D7%9D-)  
   * [שושנונים](https://www.perfectreef.co.il/249452-%D7%A9%D7%95%D7%A9%D7%A0%D7%95%D7%A0%D7%99%D7%9D)  
   * [אנגלים ננסיים](https://www.perfectreef.co.il/249453-%D7%90%D7%A0%D7%92%D7%9C%D7%99%D7%9D-%D7%A0%D7%A0%D7%A1%D7%99%D7%99%D7%9D)  
   * [פזיות ](https://www.perfectreef.co.il/249454-%D7%A4%D7%96%D7%99%D7%95%D7%AA-)  
   * [בלנים](https://www.perfectreef.co.il/249455-%D7%91%D7%9C%D7%A0%D7%99%D7%9D)  
   * [פרפרונים](https://www.perfectreef.co.il/249456-%D7%A4%D7%A8%D7%A4%D7%A8%D7%95%D7%A0%D7%99%D7%9D)  
   * [אבובוניים](https://www.perfectreef.co.il/254065-%D7%90%D7%91%D7%95%D7%91%D7%95%D7%A0%D7%99%D7%99%D7%9D)  
   * [קרדינלים](https://www.perfectreef.co.il/249458-%D7%A7%D7%A8%D7%93%D7%99%D7%A0%D7%9C%D7%99%D7%9D)  
   * [אלמוגיות](https://www.perfectreef.co.il/249459-%D7%90%D7%9C%D7%9E%D7%95%D7%92%D7%99%D7%95%D7%AA)  
   * [דרגונטים](https://www.perfectreef.co.il/249460-%D7%93%D7%A8%D7%92%D7%95%D7%A0%D7%98%D7%99%D7%9D)  
   * [מורנות](https://www.perfectreef.co.il/249461-%D7%9E%D7%95%D7%A8%D7%A0%D7%95%D7%AA)  
   * [גובים](https://www.perfectreef.co.il/249462-%D7%92%D7%95%D7%91%D7%99%D7%9D)  
   * [לוקוסים](https://www.perfectreef.co.il/249463-%D7%9C%D7%95%D7%A7%D7%95%D7%A1%D7%99%D7%9D)  
   * [הוק-פישים](https://www.perfectreef.co.il/249464-%D7%94%D7%95%D7%A7-%D7%A4%D7%99%D7%A9%D7%99%D7%9D)  
   * [נתחנים ](https://www.perfectreef.co.il/249466-%D7%A0%D7%AA%D7%97%D7%A0%D7%99%D7%9D-)  
   * [נצרנים](https://www.perfectreef.co.il/249467-%D7%A0%D7%A6%D7%A8%D7%A0%D7%99%D7%9D)  
   * [אנגלים](https://www.perfectreef.co.il/248956-%D7%90%D7%A0%D7%92%D7%9C%D7%99%D7%9D)  
   * [חד קוציים](https://www.perfectreef.co.il/254928-%D7%97%D7%93-%D7%A7%D7%95%D7%A6%D7%99%D7%99%D7%9D)  
   * [ואראס ותוכינונים](https://www.perfectreef.co.il/254172-%D7%95%D7%90%D7%A8%D7%90%D7%A1-%D7%95%D7%AA%D7%95%D7%9B%D7%99%D7%A0%D7%95%D7%A0%D7%99%D7%9D)  
   * [כרומיסים](https://www.perfectreef.co.il/249457-%D7%9B%D7%A8%D7%95%D7%9E%D7%99%D7%A1%D7%99%D7%9D)  
   * [דגי מים מלוחים למתחילים](https://www.perfectreef.co.il/264340-%D7%93%D7%92%D7%99-%D7%9E%D7%99%D7%9D-%D7%9E%D7%9C%D7%95%D7%97%D7%99%D7%9D-%D7%9C%D7%9E%D7%AA%D7%97%D7%99%D7%9C%D7%99%D7%9D)
* [אינדקס צמחי מים](https://www.perfectreef.co.il/492970-%D7%90%D7%99%D7%A0%D7%93%D7%A7%D7%A1-%D7%A6%D7%9E%D7%97%D7%99-%D7%9E%D7%99%D7%9D)  
   * [צמחי הייטק](https://www.perfectreef.co.il/492975-%D7%A6%D7%9E%D7%97%D7%99-%D7%94%D7%99%D7%99%D7%98%D7%A7)  
   * [צמחי לאוטק](https://www.perfectreef.co.il/492983-%D7%A6%D7%9E%D7%97%D7%99-%D7%9C%D7%90%D7%95%D7%98%D7%A7)  
   * [צמחי בריכה](https://www.perfectreef.co.il/492998-%D7%A6%D7%9E%D7%97%D7%99-%D7%91%D7%A8%D7%99%D7%9B%D7%94)

[ 03-7443033 ](tel:03-7443033) 

### 

****ברוכים הבאים לאתר של פרפקט ריף !**

**מזמינים אתכם להנות ממשלוח חינם בקנייה מעל 250₪ לכל רחבי הארץ עד פתח הבית**

**\*\* עד 15 קילו, לא כולל אקווריומים, לא כולל דגים \*\***

[ ![no-lazy](https://d3m9l0v76dty0.cloudfront.net/system/photos/668495/original/6ab5032cdbf52e69098ab8f6b6752f34.png?1645015111) ](https://api.whatsapp.com/send?phone=972528508504) 

### 

**ברוכים הבאים לאינדקס דגי הנוי של פרפקט ריף!**

**קניית דגי נוי וצמחים חיים מתבצעת אך ורק בחנות, איננו מבצעים משלוחים של דגים!**
```

